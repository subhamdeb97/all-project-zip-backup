import { USER_TYPE } from '../config/constants';
import { DISPUTE_ROUTE, COUNTERPARTY_ROUTE } from '../../dist-server/config/constants';
import { isNull } from 'lodash';

export const redirectUrl = async(settlementDetails) => {
  if (settlementDetails.role === USER_TYPE.DISPUTE) {
    if (
      Object.keys(settlementDetails).length !== 0 &&
      settlementDetails.length !== 0
    ) {
      if ( typeof (settlementDetails.disputantsettlementstatus) === 'undefined' &&
        typeof (settlementDetails.counterpartysettlementstatus) === 'undefined') {
        return DISPUTE_ROUTE.STEP0.URL;
      }
      if (
        !settlementDetails.disputantsettlementstatus &&
        !settlementDetails.counterpartysettlementstatus &&
        typeof (settlementDetails.disputantsettlementstatus) !== 'undefined' &&
        typeof (settlementDetails.counterpartysettlementstatus) !== 'undefined'
      ) {
        if (settlementDetails.settlementCount === 2) {
          return DISPUTE_ROUTE.NO_SETTLEMENT.URL;
        }
        if (isNull(settlementDetails.settlementOverlap)) {
          return DISPUTE_ROUTE.SETTLEMENT_OVERLAP.URL;
        }
      }
      if (
        settlementDetails.disputantsettlementDecline ||
        settlementDetails.counterpartysettlementDecline
      ) {
        return DISPUTE_ROUTE.SETTLEMENT_DECLINE.URL;
      }
      // if (
      //   settlementDetails.disputantSettlementAgreement &&
      //   !settlementDetails.counterpartySettlementAcceptance &&
      //   !settlementDetails.counterpartySettlementAcceptance
      // ) {
      //   return DISPUTE_ROUTE.SETTLEMENT_OFFER_ACCEPTANCE.URL;
      // }
      if (
        settlementDetails.counterpartySettlementAgreement &&
        settlementDetails.disputantSettlementAgreement
      ) {
        return DISPUTE_ROUTE.SETTLEMENT_RESOLVED.URL;
      }
      if (!settlementDetails.disputeSettlementAcceptance) {
        if (
          settlementDetails.counterpartysettlementstatus &&
          settlementDetails.disputantsettlementstatus &&
          !settlementDetails.disputantPaymentstatus
        ) {
          if (
            !settlementDetails.counterPartyShowSettlementFigure ||
            !settlementDetails.disputantShowSettlementFigure
          ) {
            if (!settlementDetails.disputantShowSettlementFigure) {
              return DISPUTE_ROUTE.DISPUTANT_SETTLED.URL;
            } else {
              return DISPUTE_ROUTE.STEP1.URL;
            }
          }
          return DISPUTE_ROUTE.STEP2.URL;
        } else {
          if (
            !settlementDetails.disputantsettlementstatus &&
            settlementDetails.counterpartysettlementstatus
          ) {
            if (
              (!settlementDetails.disputantsettlementstatus &&
                !settlementDetails.counterpartysettlementstatus &&
                !settlementDetails.settlementOverlap) ||
              settlementDetails.counterpartysettlementstatus
            ) {
              if (settlementDetails.settlementCount === 2) {
                return DISPUTE_ROUTE.NO_SETTLEMENT.URL;
              }
              if (settlementDetails.settlementOverlap === null) {
                return DISPUTE_ROUTE.SETTLEMENT_OVERLAP.URL;
              }
            }
            return DISPUTE_ROUTE.STEP0.URL;
          }
          if (
            settlementDetails.counterpartysettlementstatus &&
            settlementDetails.disputantsettlementstatus &&
            settlementDetails.disputantPaymentstatus &&
            !settlementDetails.disputeSettlementAcceptance
          ) {
            return DISPUTE_ROUTE.STEP3.URL;
          }

          return DISPUTE_ROUTE.STEP1.URL;
        }
      } else {
        if (
          settlementDetails.counterpartysettlementstatus &&
          settlementDetails.disputantsettlementstatus &&
          settlementDetails.disputantPaymentstatus &&
          !settlementDetails.bankDetails
        ) {
          return DISPUTE_ROUTE.STEP4.URL;
        }
        // if (
        //   settlementDetails.counterpartysettlementstatus &&
        //   settlementDetails.disputantsettlementstatus &&
        //   settlementDetails.disputantPaymentstatus &&
        //   settlementDetails.bankDetails &&
        //   !settlementDetails.disputantSettlementAgreement &&
        //   !settlementDetails.counterpartySettlementAcceptance
        // ) {
        //   return DISPUTE_ROUTE.SETTLEMENT_OFFER_ACCEPTANCE.URL;
        // }
        if (
          settlementDetails.counterpartysettlementstatus &&
          settlementDetails.disputantsettlementstatus &&
          settlementDetails.disputantPaymentstatus &&
          settlementDetails.bankDetails &&
          !settlementDetails.disputantSettlementAgreement
        ) {
          return DISPUTE_ROUTE.STEP5.URL;
        }

        if (!settlementDetails.bankDetails) return DISPUTE_ROUTE.STEP4.URL;
        if (
          settlementDetails.bankDetails &&
          settlementDetails.disputantSettlementAgreement
        )
          return DISPUTE_ROUTE.SETTLEMENT_OFFER_ACCEPTANCE.URL;
      }
    } else {
      return DISPUTE_ROUTE.STEP0.URL;
    }
  }
  if (settlementDetails.role === USER_TYPE.COUNTERPARTY) {
    if ( typeof (settlementDetails.disputantsettlementstatus) === 'undefined' &&
    typeof (settlementDetails.counterpartysettlementstatus) === 'undefined') {
      return COUNTERPARTY_ROUTE.STEP0.URL;
    }
    if (settlementDetails && settlementDetails.length === 0) {
      return COUNTERPARTY_ROUTE.STEP0.URL;
    } else {
      if (
        !settlementDetails.disputantsettlementstatus ||
        !settlementDetails.counterpartysettlementstatus
      ) {
        if (settlementDetails.settlementCount === 2) {
          return COUNTERPARTY_ROUTE.NO_SETTLEMENT.URL;
        }
        if ( isNull(settlementDetails.settlementOverlap)) {
          if (settlementDetails.counterpartysettlementstatus) {
            return COUNTERPARTY_ROUTE.WAITING_SCREEN.URL;
          }
          if (
            !settlementDetails.counterpartysettlementstatus &&
            settlementDetails.settlementCount === 0
          ) {
            return COUNTERPARTY_ROUTE.STEP0.URL;
          }
          if (
            !settlementDetails.counterpartysettlementstatus &&
            settlementDetails.settlementCount === 1
          ) {
            return COUNTERPARTY_ROUTE.NOT_SETTLED.URL;
          }
        }
      }
      // if (
      //   settlementDetails.disputantsettlementDecline ||
      //   settlementDetails.counterpartysettlementDecline
      // ) {
      //   return COUNTERPARTY_ROUTE.SETTLEMENT_DECLINE.URL;
      // }
      if (
        settlementDetails.counterpartySettlementAgreement &&
        settlementDetails.counterpartySettlementAcceptance &&
        !settlementDetails.disputantSettlementAgreement &&
        !settlementDetails.disputantSettlementAgreement
      ) {
        return COUNTERPARTY_ROUTE.WAITING_ACCEPT.URL;
      }
      if (
        !settlementDetails.disputantsettlementstatus &&
        settlementDetails.counterpartysettlementstatus
      ) {
        return COUNTERPARTY_ROUTE.SUBMITTED.URL;
      }
      if (
        settlementDetails.counterpartySettlementAgreement &&
        settlementDetails.disputantSettlementAgreement
      ) {
        return COUNTERPARTY_ROUTE.SETTLEMENT_RESOLVED.URL;
      }
      if (
        settlementDetails.disputantsettlementstatus &&
        settlementDetails.counterpartysettlementstatus
      ) {
        if (settlementDetails.settlementOverlap) {
          // for show settlement figure or not in settlement offer screen
          if (settlementDetails.counterPartyShowSettlementFigure) {
            if (
              settlementDetails.bankDetails &&
              !settlementDetails.counterpartySettlementAcceptance
            ) {
              if (!settlementDetails.counterPartyPaymentstatus) {
                return COUNTERPARTY_ROUTE.COUNTERPARTY_UNLOCK_SETTLEMENT.URL;
              }
              if (!settlementDetails.bankDetails) {
                return COUNTERPARTY_ROUTE.WAITING_SCREEN.URL;
              }
              return COUNTERPARTY_ROUTE.STEP2.URL;
            } else if (!settlementDetails.bankDetails) {
              if (
                settlementDetails.counterPartyShowSettlementFigure &&
                settlementDetails.disputantShowSettlementFigure &&
                !settlementDetails.counterPartyPaymentstatus
              ) {
                return COUNTERPARTY_ROUTE.COUNTERPARTY_UNLOCK_SETTLEMENT.URL;
              }
              if (settlementDetails.disputantShowSettlementFigure) {
                return COUNTERPARTY_ROUTE.STEP2.URL;
              } else {
                return COUNTERPARTY_ROUTE.SUBMITTED.URL;
              }
            } else if (
              settlementDetails.bankDetails &&
              settlementDetails.counterpartySettlementAcceptance
            ) {
              return COUNTERPARTY_ROUTE.STEP5.URL;
            }
          } else {
            return COUNTERPARTY_ROUTE.STEP1.URL;
          }
        }
      } else {
        return COUNTERPARTY_ROUTE.STEP0.URL;
      }
    }
  }
};
