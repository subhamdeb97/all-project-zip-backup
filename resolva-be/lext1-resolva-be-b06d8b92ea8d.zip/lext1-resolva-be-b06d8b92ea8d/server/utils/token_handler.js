import * as jwt from 'jsonwebtoken';
import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS } from '../config/constants';

/**
 * Functionality used to generate a token on successful login
 * @argument {user} user object
 * @returns {String} Token
 */
export const generate = async(user) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  const constants = Container.get(DEPENDENCY_CONTAINERS.CONSTANTS);
  try {
    const payload = {
      email: user.email,
      id: user._id,
      role: user.role
    };
    return await jwt.sign(payload, constants.JWT.SECRET_KEY);
  } catch (err) {
    logger.error(`Error while generating token for user ${user.email} ${err}`);
    throw err;
  }
};

/**
 * Functionality used to verify/decode a token
 * @argument {token} token, Token
 * @argument {id} id User id
 * @returns {Boolean} True or false
 */
export const verifyUser = async(token, id) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  const userController = Container.get(DEPENDENCY_CONTAINERS.USER_CONTROLLER);
  try {
    const userData = await userController.getUserById(id);
    if (!userData) return;
    // eslint-disable-next-line consistent-return
    return !( id === userData._id && id === token.id);
  } catch (err) {
    logger.error(`Error while verifying token for user ${err}`);
    throw err;
  }
};

module.exports = {
  generate,
  verifyUser
};
