
import { CORS, CONSTANTS } from './config/constants';
import { UNAUTHORIZED } from 'http-status-codes';

/**
 * CORS controller which controls the cross domain access
 * @returns {Boolean} it returns a boolean value which indicates
 * the requested host is a whitelist(allowed) or not
 * @param {*} req request from the client
 * @param {*} res request to the client from server
 * @param {*} next middleware to next request
 */
export const allowCrossDomain = (req, res, next) => {
  const origin = req.headers.origin || CONSTANTS.LOCAL_HOST; // for allowing localhost api hits
  const whitelist = CORS.ALLOWED_DOMAINS.split(',');
  if (whitelist.indexOf(origin) > -1) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', CORS.CORS_ALLOW_METHODS);
    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', CORS.HEADERS);
    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', CORS.CREDENTIAL_STATUS);
    // Pass to next layer of middleware
    return next();
  } else {
    return res.status(UNAUTHORIZED).send({
      error: CORS.CORS_REJECT
    });
  }
};

module.exports = {
  allowCrossDomain
};
