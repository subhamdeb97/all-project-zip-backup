import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS, ACTIVITY } from '../../config/constants';
import Bank from '../models/bank';
import Transaction from '../models/transaction';
import Workspace from '../models/workspace';
import { updateActivity } from './activity';

/**
 * Functionality used to create the new bank details to the database
 * @param {*} bankdetails bank object
 * @returns {Object} newly created bank data
 */
export const createBankDetails = async(bankdetails) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    const workSpaceExist = await Workspace.findOne({
      _id: bankdetails.workSpaceId,
    });
    if (!workSpaceExist) {
      throw 'WorkSpace Not found';
    }
    const activity = {
      description: [ACTIVITY.SUBMITTED_BANKDETAILS],
      workSpaceId: bankdetails.workSpaceId
    };
    await updateActivity(activity);

    await Transaction.findOneAndUpdate({
      workSpaceId: bankdetails.workSpaceId
    }, {
      bankDetails: true
    });

    const bank = new Bank(bankdetails);
    await bank.save();
    return await Transaction.findOne({
      workSpaceId: bankdetails.workSpaceId
    }).lean();
  } catch (err) {
    logger.error(`Error while creating bank details ${err}`);
    throw err;
  }
};
/**
 * Functionality used to get bank details database
 * @param {*} id bank object
 * @returns {Object} bank data
 */
export const getBankDetails = async(id) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    const bank = await Bank.findOne({
      workSpaceId: id
    }).lean();
    return bank;
  } catch (err) {
    logger.error(`Error while creating bank details ${err}`);
    throw err;
  }
};
/**
 * Functionality used to edit bank details database
 * @param {*} bankdetails bank object
 * @returns {Object} bank data
 */
export const editBankDetails = async(bankdetails) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    const workSpaceExist = await Workspace.findOne({
      _id: bankdetails.workSpaceId,
    });
    if (!workSpaceExist) {
      throw 'WorkSpace Not found';
    }
    const bank = await Bank.findOneAndUpdate({
      workSpaceId: bankdetails.workSpaceId
    }, bankdetails);
    return bank;
  } catch (err) {
    logger.error(`Error while creating bank details ${err}`);
    throw err;
  }
};

module.exports = {
  createBankDetails,
  getBankDetails,
  editBankDetails
};
