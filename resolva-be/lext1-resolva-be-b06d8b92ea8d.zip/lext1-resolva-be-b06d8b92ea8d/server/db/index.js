/* eslint-disable no-undef */
import mongoose from 'mongoose';
import { MONGO_CONSTANTS, CONSTANTS } from '../config/constants';

/**
 * Functionality used to import all the required models
 * under the models directory and sync the mongo database
 * @returns {mongoInstance} returns synced instance data
 */

export const connector = () => {
  try {
    mongoose.connect(
      process.env.MONGO_DB_URI,
      {
        useCreateIndex: true,
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useFindAndModify: false
      },
      err => {
        if (err) {
          console.error(`👎 ${MONGO_CONSTANTS.CONNECTION_ERROR} 👎`, err);
          throw err;
        }
        console.info(`👍 ${MONGO_CONSTANTS.CONNECTION_SUCCESSFUL} 👍`);
      }
    );
  } catch (err) {
    console.error(`👎 ${MONGO_CONSTANTS.CONNECTION_ERROR} 👎`, err);
  }
};

let db = mongoose.connection;

db.on(MONGO_CONSTANTS.DISCONNECTED, () => {
  console.info(`⚠️  ${MONGO_CONSTANTS.CONNECTION_DISCONNECTED} ⚠️`);
});

// Stopping all the open connection of database when the process is stopped.
process.on(MONGO_CONSTANTS.SIGINT, () => {
  mongoose.connection.close(() => {
    console.info(`⚠️  ${MONGO_CONSTANTS.PROCESS_TERMIATED} ⚠️`);
    // eslint-disable-next-line no-process-exit
    process.exit(CONSTANTS.NUMBERS.ZERO);
  });
});
