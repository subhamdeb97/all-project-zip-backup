import * as mongoose from 'mongoose';
const Schema = mongoose.Schema;

/**
 * Workspace model design.
 * @returns {mongooseModel} it returns the schema model of workspace
 */

const workSpace = new Schema(
  {
    disputeId: {
      type: String,
    },
    counterpartyContact: {
      type: String,
    },
    ABN: {
      type: String,
    },
    counterpartyABN: {
      type: String,
    },
    email: {
      type: String,
    },
    mobile: {
      type: String,
    },
    businessName: {
      type: String,
    },
    businessType: {
      type: String,
    },
    address: {
      type: String,
    },
    city: {
      type: String,
    },
    state: {
      type: String,
    },
    postalCode: {
      type: Number,
    },
    disputeType: {
      type: Number,
    },
    introduction: {
      type: String,
    },
    counterparyIntroduction: {
      type: String,
      default: ''
    },
    claimValue: {
      type: Number,
    },
    token: {
      type: String,
    },
    counterPartyName: {
      type: String,
    },
    counterPartyBussiness: {
      type: String,
    },
    counterPartyEmail: {
      type: String,
    },
    createdBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
    counterPartyJoined: {
      type: Boolean,
      default: false
    },
    counterPartyViewed: {
      type: Boolean,
      default: false
    },
    disputantSettlementUrl: {
      type: String
    },
    counterPartySettlementUrl: {
      type: String
    },
    createdAt: {
      type: Date,
      default: Date.now()
    },
    disputantConfidentiality: {
      type: Boolean,
      default: false
    },
    counterPartyConfidentiality: {
      type: Boolean,
      default: false
    },
    isCounterpartyUnsubscribed: {
      type: Boolean,
      default: false
    }
  },
  { timestamps: true }
);

export default mongoose.model('Workspace', workSpace);
