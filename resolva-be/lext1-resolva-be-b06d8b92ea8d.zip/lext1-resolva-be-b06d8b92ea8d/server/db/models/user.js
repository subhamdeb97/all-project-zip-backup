import * as mongoose from 'mongoose';
const Schema = mongoose.Schema;

/**
 * User model design for dispute.
 * @returns {mongooseModel} it returns the schema model for dispute user
 */
const user = new Schema({
  // workSpaceId: {
  //   type: Schema.Types.ObjectId,
  //   ref: 'Workspace'
  // },
  email: {
    type: String,
    required: [true, 'can\'t be blank'],
  },
  name: {
    type: String,
    required: [true, 'can\'t be blank'],
  },
  hash: {
    type: String,
  },
  role: {
    type: String,
    // required: [true, 'can\'t be blank'],
  },
  otp: {
    type: Number
  }
},
{timestamps: true});

user.index({
  email: 1,
}, {
  unique: true
});

export default mongoose.model('User', user);
