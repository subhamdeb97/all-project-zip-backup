import { Router } from 'express';
import { celebrate, Joi, Segments } from 'celebrate';
import {
  getWorkspace,
  getUserWorkspace,
  getWorkspaceByEmail,
  updateWorkspaceById,
  createWorkspace,
  inviteStatus,
  unsubscribe,
  updateStatus,
  updateWorkspace,
} from '../../services/workspace/workspace';

export default (app) => {
  const router = Router();
  app.use('/workspace', router);
  /**
   * Route to get workspace by ID
   */
  router.route('/:id').get(
    celebrate({
      [Segments.PARAMS]: {
        id: Joi.string().required(),
      },
    }),
    getWorkspace
  );
  /**
   * Route to get workspace by userID
   */
  router.route('/user/:id').get(
    celebrate({
      [Segments.PARAMS]: {
        id: Joi.string().required(),
      },
    }),
    getUserWorkspace
  );
  /**
   * Route to get workspace by user email
   */
  router.route('/user/email/:email').get(
    celebrate({
      [Segments.PARAMS]: {
        email: Joi.string().required(),
      },
    }),
    getWorkspaceByEmail
  );
  /**
   * Route to edit workpace
   */
  router.route('/edit/:id').post(
    celebrate({
      [Segments.PARAMS]: {
        id: Joi.string().required(),
      },
      [Segments.BODY]: Joi.object().keys({
        email: Joi.string().required(),
        disputantName: Joi.string().required(),
        businessName: Joi.string().allow(''),
        introduction: Joi.string().required(),
        counterPartyName: Joi.string().required(),
        counterPartyBussiness: Joi.string().allow(''),
        counterPartyEmail: Joi.string().required(),
      }),
    }),
    updateWorkspaceById
  );
  /**
   * Route to create new workspace
   */
  router.route('/create').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        id: Joi.string(),
        email: Joi.string().required(),
        ABN: Joi.string().allow(''),
        mobile: Joi.string().required(),
        businessName: Joi.string().allow(''),
        businessType: Joi.string().allow(''),
        address: Joi.string().required(),
        city: Joi.string().required(),
        state: Joi.string().required(),
        postalCode: Joi.string().required(),
        disputeType: Joi.string().required(),
        introduction: Joi.string().required(),
        claimValue: Joi.string().required(),
        counterPartyName: Joi.string().required(),
        counterPartyBussiness: Joi.string().allow(''),
        counterPartyEmail: Joi.string().required(),
        envelopeArgs: Joi.object().allow(''),
        disputantName: Joi.string().required(),
        counterpartyContact: Joi.string().required(),
        counterpartyABN: Joi.string().allow('')
      }),
    }),
    createWorkspace
  );
  /**
   * Route to update the status
   */
  router.route('/updateStatus').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        id: Joi.string().required(),
        counterPartyViewed: Joi.boolean(),
        viewedAndJoined: Joi.boolean(),
        counterPartyJoined: Joi.boolean(),
        disputantConfidentiality: Joi.boolean(),
        counterPartyConfidentiality: Joi.boolean(),
      }),
    }),
    updateStatus
  );
  /**
   * Route to check invite status
   */
  router.route('/invite/:id/:role').get(
    celebrate({
      [Segments.PARAMS]: {
        id: Joi.string().required(),
        role: Joi.string().required(),
      },
    }),
    inviteStatus
  );
  /**
   * Route to Unsubscribe
   */
  router.route('/unsubscribe/:role/:id').get(
    celebrate({
      [Segments.PARAMS]: {
        id: Joi.string().required(),
        role: Joi.string().required(),
      },
    }),
    unsubscribe
  );
  /**
   * Route to update workspace
   */
  router.route('/update/:id').post(celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().required()
    },
    [Segments.BODY]: Joi.object().keys({
      workspace: Joi.object().required(),
    })
  }), updateWorkspace);
};
