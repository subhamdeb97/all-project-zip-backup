import { Router } from 'express';
const { celebrate, Joi, errors, Segments } = require('celebrate');
import { getUserDetail, getUserEmail, sendGrid } from '../../services/user/find';
import {createCounterParty } from '../../services/user/create';

/**
 * This is common router which will navigate the api request as per the
 * routes provided in the request url
 * @param {app} app app instance
 * @returns {router} router instance
 */
export default app => {
  const router = Router();
  app.use('/users', router);

  /**
   * Route to fetch a list of all users
   */
  router.route('/:email').get(
    celebrate({
      [Segments.PARAMS]: {
        email: Joi.string().required()
      }
    }), getUserEmail);
  /**
   * Route to send email template form sendGrid
   */
  router.route('/sendgrid/:workspaceId').get(
    celebrate({
      [Segments.PARAMS]: {
        workspaceId: Joi.string().required()
      }
    }), sendGrid);
  /**
   * Route to Join the counterParty in workspace
   */
  router.route('/workspace/join/:id').post(celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().required()
    },
    [Segments.BODY]: Joi.object().keys({
      email: Joi.string().required(),
      password: Joi.string().required(),
      role: Joi.string().required(),
      envelopeArgs: Joi.object().required()
    })
  }), createCounterParty);
  /**
   * Route to get the user details
   */
  router.route('/find').get(getUserDetail);

  app.use(errors());
};
