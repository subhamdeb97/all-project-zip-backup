import { Router } from 'express';
const { celebrate, Joi, Segments } = require('celebrate');
import {
  createTransaction,
  updateDisputeDetails,
  getTranactionByWorkspaceId,
} from '../../services/transaction/transaction';
/**
 * This is common router which will navigate the api request as per the
 * routes provided in the request url
 * @param {app} app app instance
 * @returns {router} router instance
 */

export default (app) => {
  const router = Router();
  app.use('/transaction', router);
  /**
   * Route to create new settlement details
   */
  router.route('/').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        workSpaceId: Joi.string().required(),
        role: Joi.string().required(),
        counterpartysettlementDecline: Joi.boolean(),
        counterpartySettlementAgreement: Joi.boolean(),
        counterpartySettlementAcceptance: Joi.boolean(),
        disputantsettlementDecline: Joi.boolean(),
        disputantSettlementAgreement: Joi.boolean(),
        disputeSettlementAcceptance: Joi.boolean(),
        disputantsettlementstatus: Joi.boolean(),
        counterpartysettlementstatus: Joi.boolean(),
        settlementAcceptance: Joi.boolean(),
        disputeCurrentSettlementValue: Joi.number(),
        disputePreviousSettlementValue: Joi.number(),
        counterPartyCurrentSettlementValue: Joi.number(),
        counterPartyPreviousSettlementValue: Joi.number(),
        counterPartyShowSettlementFigure: Joi.boolean(),
        disputantShowSettlementFigure: Joi.boolean(),
        disputantPaymentstatus: Joi.boolean(),
        counterPartyPaymentstatus: Joi.boolean()
      }),
    }),
    createTransaction
  );
  /**
   * Route to get settlement details based on workspace ID
   */
  router.route('/:id/:role').get(celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().required(),
      role: Joi.string().required()
    }
  }),
  getTranactionByWorkspaceId);

  /**
   * Route to update settlement detaisl based on workspace ID
   */
  router.route('/update').put(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        workSpaceId: Joi.string().required(),
        disputeStatus: Joi.boolean(),
        currentSettlementValue: Joi.number(),
        previousSettlementValue: Joi.number(),
      }),
    }),
    updateDisputeDetails
  );
};
