import { Router } from 'express';
const { celebrate, Joi, Segments } = require('celebrate');
import { addBankDetails, getBankDetails, editBankDetails } from '../../services/bank/bank';

/**
 * This is common router which will navigate the api request as per the
 * routes provided in the request url
 * @param {app} app app instance
 * @returns {router} router instance
 */
export default (app) => {
  const router = Router();

  app.use('/bank', router);
  /**
   * Route to add bank details
   */
  router.route('/').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        workSpaceId: Joi.string().required(),
        name: Joi.string().required(),
        bsb: Joi.string().required(),
        accountNumber: Joi.string().required(),
      }),
    }),
    addBankDetails
  );
  /**
   * Route to get bank details
   */
  router.route('/:id').get(
    celebrate({
      [Segments.PARAMS]: {
        id: Joi.string().required()
      }
    }),
    getBankDetails
  );
  /**
   * Route to update bank details
   */
  router.route('/edit').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        workSpaceId: Joi.string().required(),
        name: Joi.string().required(),
        bsb: Joi.string().required(),
        accountNumber: Joi.string().required(),
      }),
    }),
    editBankDetails
  );
};
