import express from 'express';
import user from './user';
import auth from './auth';
import transaction from './transaction';
import docusign from './docusign';
import workspace from './workspace';
import activity from './activity';
import stripe from './stripe';
import bank from './bank';

const router = express.Router();

user(router);
auth(router);
transaction(router);
docusign(router);
workspace(router);
activity(router);
stripe(router);
bank(router);

export default router;
