import { Router } from 'express';
import { celebrate, Joi, errors, Segments } from 'celebrate';
import { envelop, getsignature, getEmbedded, getEnvelope} from '../../services/docusign/docusign';

/**
 * This is common router for docusign
 * routes provided in the request url
 * @param {app} app app instance
 * @returns {router} router instance
 */
export default (app) => {
  const router = Router();
  app.use('/docusign', router);
  /**
   * Route to get generate URL from docusign
   */
  router.route('/embedded').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        envelopeArgs: Joi.object().required()
      })
    }), envelop);
  /**
   * Route to get signature from docusing
   */
  router.route('/signature').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        envelopeId: Joi.string().required(),
        workspaceId: Joi.string().required(),
        recipientId: Joi.string().required(),
        type: Joi.string().required(),
        role: Joi.string().required(),
      })
    }), getsignature);
  /**
   * Route to create new docusing URL
   */
  router.route('/create').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        workspaceId: Joi.string().required(),
        userId: Joi.string().required(),
        role: Joi.string().required(),
      })
    }), getEmbedded);
  /**
   * Route to get envelope form docusing
   */
  router.route('/envelope/:id').get(
    celebrate({
      [Segments.PARAMS]: {
        id: Joi.string().required()
      }
    }),
    getEnvelope
  );
  app.use(errors());

};
