
import { NOT_FOUND } from 'http-status-codes';

// Custom 404 handler
export default () => {
  return (req, res, next) => { /* eslint no-unused-vars:0 */
    res.status(NOT_FOUND).send('<h4>Page requested not found</h4>');
  };
};
