import { BAD_REQUEST, INTERNAL_SERVER_ERROR } from 'http-status-codes';
import { ENVIRONMENT } from '../config/constants';
const production = ENVIRONMENT === 'PROD';

/**
 * Functionality which handles the error scenario
 * through out the app
 * @returns { Object| HTML} error object
 */
export default () => {
  return apiErrorHandler = (err, req, res, next) => { // eslint-disable-line
    let status = err.status || err.statusCode || res.statusCode || INTERNAL_SERVER_ERROR;
    if (status < BAD_REQUEST) {
      status = INTERNAL_SERVER_ERROR;
    }

    let body = {
      status: status,
      message: err.message || 'Server Down' // eslint-disable-line
    };

    // add the stacktrace when not in production
    if (!production) {
      body.stack = err.stack;
    }

    // internal server errors
    if (status >= INTERNAL_SERVER_ERROR) {
      // eslint-disable-next-line
      body.message = 'Internal Server Error'; // generic error message
    }

    res.status(status).send(`<h4>Server Error </h4>
            <div style="background: yellow; padding: 10px;">
                <h4>Status: </h4>
                <span>${body.status}</span>
                <h4>Message:</h4>
                <span>${body.message}</span>
                <h4>Stack Trace:</h4>
                <p>${body.stack}</p>
            </div>`);
  };
};
