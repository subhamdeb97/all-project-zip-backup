import { CREATED, UNAUTHORIZED, OK } from 'http-status-codes';
import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS } from '../../config/constants';

/**
 * Functionality used to create a new Bank details to the database
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {Object} new bank details data
 */
export const addBankDetails = async(req, res, next) => {
  try {
    const formattedData = { ...req.body };
    const bankController = Container.get(DEPENDENCY_CONTAINERS.BANK_CONTROLLER);
    const bank = await bankController.createBankDetails(formattedData);
    return res.status(CREATED).send(bank);
  } catch (error) {
    res.status(UNAUTHORIZED).send(error);
    next(error);
    return 'Error';
  }
};
/**
 * Functionality used to get Bank details to the database
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {Object} bank details data
 */
export const getBankDetails = async(req, res, next) => {
  const id = req.params.id;
  try {
    const bankController = Container.get(DEPENDENCY_CONTAINERS.BANK_CONTROLLER);
    const bank = await bankController.getBankDetails(id);
    return res.status(OK).send(bank);
  } catch (error) {
    res.status(UNAUTHORIZED).send(error);
    next(error);
    return 'Error';
  }
};
/**
 * Functionality used to edit Bank details to the database
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {Object} bank details data
 */
export const editBankDetails = async(req, res, next) => {
  try {
    const formattedData = { ...req.body };
    const bankController = Container.get(DEPENDENCY_CONTAINERS.BANK_CONTROLLER);
    const bank = await bankController.editBankDetails(formattedData);
    return res.status(OK).send(bank);
  } catch (error) {
    res.status(UNAUTHORIZED).send(error);
    next(error);
    return 'Error';
  }
};
