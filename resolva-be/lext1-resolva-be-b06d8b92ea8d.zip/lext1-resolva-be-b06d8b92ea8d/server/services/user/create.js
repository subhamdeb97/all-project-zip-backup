import { FORBIDDEN, CREATED, UNAUTHORIZED, } from 'http-status-codes';
import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS, ACTIVITY } from '../../config/constants';
import { createActivity } from '../../db/controller/activity';


/**
 * Functionality used to create a new user to the database
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {Object} new user data
 */
export const addUser = async(req, res, next) => {
  try {
    const formattedData = { ...req.body };
    const userController = Container.get(DEPENDENCY_CONTAINERS.USER_CONTROLLER);
    const { newUser, token, docusign } = await userController.createUser(formattedData);
    if (!newUser._id) {
      return res
        .status(FORBIDDEN)
        .send({ message: 'Something went wrong' });
    }
    return res.status(CREATED).send({ user: newUser, token: token, docusign: docusign });
  } catch (error) {
    res.status(UNAUTHORIZED).send(error);
    next(error);
    return 'Error';
  }
};
export const createCounterParty = async(req, res, next) => {
  const id = req.params.id;
  try {
    const formattedData = { ...req.body };
    const userController = Container.get(DEPENDENCY_CONTAINERS.COUNTERPARTY_CONTROLLER);
    const { newUser, token, docusign } = await userController.createCounterPartyUser(formattedData, id)
      .catch((error) => {
        res.status(UNAUTHORIZED).send(error);
      });
    const activity = {
      description: [ACTIVITY.WORKSPACE_JOINED],
      workSpaceId: id
    };
    await createActivity(activity);
    res.status(CREATED).send({ user: newUser, token: token, docusign: docusign });
  } catch (error) {
    next(error);
  }
};
module.exports = {
  addUser,
  createCounterParty
};
