import { OK, CREATED, BAD_REQUEST} from 'http-status-codes';
import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS } from '../../config/constants';
/**
 * Functionality used to get workspace by id
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {object} workspace
 */
export const getWorkspace = async(req, res, next) => {
  const id = req.params.id;
  try {
    const workspaceController = Container.get(DEPENDENCY_CONTAINERS.WORKSPACE_CONTROLLER);
    const workspace = await workspaceController.getWorkspaceById(id);
    res.status(OK).send({ workspace: workspace });
  } catch (error) {
    next(error);
  }
};
/**
 * Functionality used to get workspace by user id
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {object} workspace
 */
export const getUserWorkspace = async(req, res, next)=>{
  const id = req.params.id;
  try {
    const workspaceController = Container.get(DEPENDENCY_CONTAINERS.WORKSPACE_CONTROLLER);
    const workspace = await workspaceController.getWorkspaceByUserId(id);
    res.status(OK).send({ workspace: workspace });
  } catch (error) {
    next(error);
  }
};
/**
 * Functionality used to get workspace by email
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {object} workspace
 */
export const getWorkspaceByEmail = async(req, res, next)=>{
  const email = req.params.email;
  try {
    const workspaceController = Container.get(DEPENDENCY_CONTAINERS.WORKSPACE_CONTROLLER);
    const workspace = await workspaceController.getWorkspaceByEmail(email);
    res.status(OK).send({ workspace: workspace });
  } catch (error) {
    next(error);
  }
};
/**
 * Functionality used to update workspace by id
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {object} workspace
 */
export const updateWorkspaceById = async(req, res, next)=>{
  const id = req.params.id;
  const formattedData = { ...req.body };
  try {
    const workspaceController = Container.get(DEPENDENCY_CONTAINERS.WORKSPACE_CONTROLLER);
    const workspace = await workspaceController.updateWorkspaceById(id, formattedData);
    res.status(OK).send({ workspace: workspace });
  } catch (error) {
    next(error);
  }
};
/**
 * Functionality used to create new workspace
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {object} workspace
 */
export const createWorkspace = async(req, res, next)=>{
  const formattedData = { ...req.body };
  try {
    const workspaceController = Container.get(DEPENDENCY_CONTAINERS.WORKSPACE_CONTROLLER);
    const { newUser, token, docusign} = await workspaceController.createWorkspace(formattedData);
    return res.status(CREATED).send({ user: newUser, token: token, docusign: docusign });
  } catch (error) {
    next(error);
  }
};
/**
 * Functionality used to update the status
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {object} workspace
 */
export const updateStatus = async(req, res, next)=>{
  const formattedData = { ...req.body };
  const id = formattedData.id;
  try {
    const workspaceController = Container.get(DEPENDENCY_CONTAINERS.WORKSPACE_CONTROLLER);
    const workspace = await workspaceController.updateStatus(id, formattedData);
    res.status(OK).send({ workspace: workspace });
  } catch (error) {
    next(error);
  }
};
/**
 * Functionality used to update the status
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {object} workspace
 */
export const updateWorkspace = async(req, res, next)=>{
  const formattedData = { ...req.body };
  const id = req.params.id;
  try {
    const workspaceController = Container.get(DEPENDENCY_CONTAINERS.WORKSPACE_CONTROLLER);
    const workspace = await workspaceController.updateWorkspace(id, formattedData.workspace);
    res.status(OK).send({ workspace: workspace });
  } catch (error) {
    next(error);
  }
};
/**
 * Functionality used to check inviteStatus
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {object} workspace
 */
export const inviteStatus = async(req, res, next)=>{
  const { id, role} = req.params;
  try {
    const workspaceController = Container.get(DEPENDENCY_CONTAINERS.WORKSPACE_CONTROLLER);
    const workspace = await workspaceController.inviteStatus(id, role);
    res.status(OK).send({ workspace: workspace });
  } catch (error) {
    next(error);
  }
};
/**
 * Functionality used to Unsubscribe
 * @param {*} req request
 * @param {*} res response
 * @returns {object} workspace
 */
export const unsubscribe = async(req, res)=>{
  const { id, role} = req.params;
  try {
    const workspaceController = Container.get(DEPENDENCY_CONTAINERS.WORKSPACE_CONTROLLER);
    const workspace = await workspaceController.unsubscribe(id, role);
    res.status(OK).send({ workspace: workspace });
  } catch (error) {
    res.status(BAD_REQUEST).send(error);
  }
};
module.exports = {
  getWorkspace,
  getUserWorkspace,
  updateWorkspaceById,
  createWorkspace,
  updateStatus,
  getWorkspaceByEmail,
  inviteStatus,
  unsubscribe,
  updateWorkspace
};
