
import { OK, UNAUTHORIZED } from 'http-status-codes';
import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS } from '../../config/constants';

/**
 * Functionality used to log in a user
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {string} token
 */
export const userLogin = async(req, res, next) => {
  try {
    const { email, password } = {...req.body };

    const userController = Container.get(DEPENDENCY_CONTAINERS.USER_CONTROLLER);
    const tokenHandler = Container.get(DEPENDENCY_CONTAINERS.TOKEN_HANDLER);
    const passwordHandler = Container.get(DEPENDENCY_CONTAINERS.PASSWORD_HANDLER);

    const user = await userController.findUserByEmail(email);
    if (!user) {
      return res.status(UNAUTHORIZED).send({message: `No user account found with this ${email}`});
    }
    // Verify password
    const userPassword = await passwordHandler.decrypt(user.hash);
    if (!(user && (userPassword === password))) {
      return res.status(UNAUTHORIZED).send({message: 'Credentials does not match'});
    }
    const token = await tokenHandler.generate(user);
    res.status(OK).send({user: user, token: token});
  } catch (error) {
    next(error);
  }
};

module.exports = {
  userLogin
};
