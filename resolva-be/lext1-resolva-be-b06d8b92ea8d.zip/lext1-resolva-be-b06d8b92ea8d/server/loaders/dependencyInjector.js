import { Container } from 'typedi';
import LoggerInstance from './logger';
import { CONSTANTS, DEPENDENCY_CONTAINERS } from '../config/constants';
import * as MongooseInstance from 'mongoose';
import * as UserControllerInstance from '../db/controller/user';
import * as TransactionControllerInstance from '../db/controller/transaction';
import * as TokenHandlerInstance from '../utils/token_handler';
import * as PasswordHandlerInstance from '../utils/password_handler';
import * as CounterPartyControllerInstance from '../db/controller/counterParty';
import * as WorkspaceControllerInstance from '../db/controller/workspace';
import * as ActivityControllerInstance from '../db/controller/activity';
import * as BankControllerInstance from '../db/controller/bank';

/**
 * Functionalilty used to set the container services
 * @returns {null} it returns null
 */
const injectorInstance = async() => {
  try {
    Container.set(DEPENDENCY_CONTAINERS.LOGGER, LoggerInstance);
    Container.set(DEPENDENCY_CONTAINERS.USER_CONTROLLER, UserControllerInstance);
    Container.set(DEPENDENCY_CONTAINERS.TRANSACTION_CONTROLLER, TransactionControllerInstance);
    Container.set(DEPENDENCY_CONTAINERS.COUNTERPARTY_CONTROLLER, CounterPartyControllerInstance);
    Container.set(DEPENDENCY_CONTAINERS.WORKSPACE_CONTROLLER, WorkspaceControllerInstance);
    Container.set(DEPENDENCY_CONTAINERS.ACTIVITY_CONTROLLER, ActivityControllerInstance);
    Container.set(DEPENDENCY_CONTAINERS.BANK_CONTROLLER, BankControllerInstance);
    Container.set(DEPENDENCY_CONTAINERS.TOKEN_HANDLER, TokenHandlerInstance);
    Container.set(DEPENDENCY_CONTAINERS.PASSWORD_HANDLER, PasswordHandlerInstance);
    Container.set(DEPENDENCY_CONTAINERS.CONSTANTS, CONSTANTS);
    Container.set(DEPENDENCY_CONTAINERS.MONGOOSE, MongooseInstance);
    return;
  } catch (err) {
    LoggerInstance.error('⚠️  Error on dependency injector instance loader: %o', err);
    throw new Error(err);
  }
};

export default injectorInstance;
