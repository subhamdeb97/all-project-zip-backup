
import winston from 'winston';
import { WINSTON_CONSTS, ENVIRONMENT, CONSTANTS } from '../config/constants';

const transports = [];
if ((ENVIRONMENT.toUpperCase() !== CONSTANTS.ENV.DEV) && (ENVIRONMENT.toUpperCase() !== CONSTANTS.ENV.LOCAL)) {
  transports.push(
    new winston.transports.Console()
  );
} else {
  transports.push(
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.cli(),
        winston.format.splat()
      )
    })
  );
}

/**
 * Functionality used to create the instance for the
 * winston logger instance
 * @returns {winstonInstance} it returns winston instance depends on the NODE_ENV
 */
const LoggerInstance = winston.createLogger({
  level: WINSTON_CONSTS.LOG_LEVEL,
  levels: winston.config.npm.levels,
  format: winston.format.combine(
    winston.format.timestamp({
      format: CONSTANTS.DATE_FORMAT
    }),
    winston.format.errors({ stack: true }),
    winston.format.splat(),
    winston.format.json()
  ),
  transports
});

export default LoggerInstance;
