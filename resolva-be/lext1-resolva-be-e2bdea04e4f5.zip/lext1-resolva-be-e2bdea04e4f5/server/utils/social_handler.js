import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS, USER_TYPE } from '../config/constants';
/**
 * Functionality used to create and authenticate a social user
 * If user does not exist a new user will be created
 * A token will be generated for the user
 * @argument {user} user object
 * @returns {String} Token
 * @param {*} userType userType
 * @param {*} userObject user object
  * @param {*} envelopeArgs docusing object
  * @param {*} role user role
 */
export const authenticate = async(user, userType, userObject, envelopeArgs, role) => {
  const tokenHandler = Container.get(DEPENDENCY_CONTAINERS.TOKEN_HANDLER);
  const userController = Container.get(DEPENDENCY_CONTAINERS.USER_CONTROLLER);
  const counterPartyController = Container.get(DEPENDENCY_CONTAINERS.COUNTERPARTY_CONTROLLER);
  let userData = await userController.findUserByEmail(user.email);
  // Sign up the user if new otherwise, login
  if (!userData) {
    if (userType === USER_TYPE.DISPUTE) {
      const userValue = {
        email: user.email,
        name: user.firstName,
        password: user.password,
        mobile: userObject.mobile,
        businessName: userObject.businessName,
        businessType: userObject.businessType,
        address: userObject.address,
        city: userObject.city,
        state: userObject.state,
        postalCode: userObject.postalCode,
        disputeType: userObject.disputeType,
        introduction: userObject.introduction,
        claimValue: userObject.claimValue,
        days: userObject.days,
        counterPartyName: userObject.counterPartyName,
        counterPartyBussiness: userObject.counterPartyBussiness,
        counterPartyEmail: userObject.counterPartyEmail,
        role: role,
        disputantName: userObject.disputantName,
        fullName: userObject.fullName,
        counterpartyContact: userObject.counterpartyContact,
        envelopeArgs: envelopeArgs
      };
      return await userController.createUser(userValue);
    } else {
      return await counterPartyController.createCounterPartyUser({
        email: user.email,
        name: user.firstName,
        password: user.password,
        envelopeArgs: envelopeArgs,
        role: role,
      }, userObject.workSpaceId).catch(error => {
        throw error;
      });
    }

  } else {
    return await tokenHandler.generate(userData);
  }
};

export const socialLogin = async(user) => {
  const userController = Container.get(DEPENDENCY_CONTAINERS.USER_CONTROLLER);
  let userData = await userController.findUserByEmail(user.email);
  if (userData) {
    return userData;
  } else {
    throw 'Email not found';
  }
};

module.exports = {
  authenticate,
  socialLogin
};
