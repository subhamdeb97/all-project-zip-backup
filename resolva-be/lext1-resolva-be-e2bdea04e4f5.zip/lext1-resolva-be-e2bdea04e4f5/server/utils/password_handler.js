import { Container } from 'typedi';
import Cryptr from 'cryptr';
import { CONSTANTS, DEPENDENCY_CONTAINERS } from '../config/constants';

const cryptr = new Cryptr(CONSTANTS.CRYPTR_KEY.SECRET);

/**
 * Functionality used to encrypt user password
 * @param {*} password password
 * @returns {String} it returns encrypted password
 */
export const encrypt = async(password) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    return await cryptr.encrypt(password);
  } catch (err) {
    logger.error(`Error while encrypting password ${err}`);
    throw err;
  }
};

/**
 * Functionality used to decrypt user password
 * @param {*} encryptedPassword encryptedPassword value
 * @returns {String} it returns decrypted password
 */
export const decrypt = async(encryptedPassword) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    return await cryptr.decrypt(encryptedPassword);
  } catch (err) {
    logger.error(`Error while decrypting password ${err}`);
    throw err;
  }
};

export const getRandomString = () =>
  Math.random()
    .toString(CONSTANTS.STRING_BASE_THIRTY_SIX)
    .slice(CONSTANTS.GET_LAST_TEN_CHAR);

export const generateOTP = () => {
  let digits = CONSTANTS.NUMBERS.LIST;

  let otpLength = CONSTANTS.NUMBERS.LENGTH;

  let otp = '';

  for (let index = 1; index <= otpLength; index++) {
    let indexValue = Math.floor(Math.random() * digits.length);

    otp = otp + digits[indexValue];
  }

  return otp;
};

module.exports = {
  encrypt,
  decrypt,
  getRandomString,
  generateOTP
};
