const CronJob = require('cron').CronJob;
import { emailTemplate } from './email-template';
// import Workspace from '../db/models/workspace';
import Tracker from '../db/models/tracker';
// import Transaction from '../db/models/transaction';
/**
 * Function to remove time in date
 * @param {time} date date with time time
 * @returns {object} date without time
 */
const dateWithoutTime = (date) => date.setHours(0, 0, 0, 0);
/**
 * Function to trigger the mail based on the cron job time
 * @param {time} time cronjob time
 * @returns {object} sendgrid mail
 */
export const cronJob = async(time) => {
  return new CronJob({
    cronTime: time,
    onTick: async() => {
      let twoDays = new Date();
      let fourDays = new Date();
      let sevenDays = new Date();
      const tracker = await Tracker.find().lean();
      console.log('tracker', tracker);
      console.log('*******-------' + new Date() + '--------*******');
      // console.log(tracker[tracker.length -1].createdAt)
      // let twoDays = new Date();
      // let fourDays = new Date();
      // let sevenDays = new Date();
      // let createdDate = new Date(tracker[tracker.length -1].createdAt);
      //  twoDays = new Date(twoDays.setDate(createdDate.getDate() + 2));
      //       fourDays = new Date(fourDays.setDate(createdDate.getDate() + 4));
      //       sevenDays = new Date(sevenDays.setDate(createdDate.getDate() + 7));
      // console.log(twoDays.toLocaleDateString(), fourDays.toLocaleDateString(), sevenDays.toLocaleDateString())
      // // console.log(createdDate,
      // +"\n tow"+ twoDays, +"\n four"+fourDays,+"\n seven"+ sevenDays)
      tracker.forEach((settlement) => {
        console.log('inside foreach---------------------->', settlement);
        if (settlement.createWorkspaceNoOffer) {
          console.log(
            'createWorkspace no offer',
            settlement.createWorkspaceNoOffer
          );
          let createdDate = new Date(settlement.createdAt);
          twoDays = new Date(twoDays.setDate(createdDate.getDate() + 2));
          fourDays = new Date(fourDays.setDate(createdDate.getDate() + 4));
          sevenDays = new Date(sevenDays.setDate(createdDate.getDate() + 7));
          console.log('two, four, seven', twoDays, fourDays, sevenDays);
          console.log(
            'date wothout time comparsion',
            dateWithoutTime(twoDays),
            dateWithoutTime(new Date())
          );
          if (
            dateWithoutTime(twoDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(fourDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(sevenDays) === dateWithoutTime(new Date())
          ) {
            console.log('difffffff', twoDays, fourDays, sevenDays);
            console.log('id', settlement.workSpaceId);
            emailTemplate(settlement.workSpaceId, 'created_workspace_no_offer');
          }
        }
        if (settlement.counterPartyNotJoin) {
          console.log('id counter party not join', settlement.workSpaceId);
          let createdDate = new Date(settlement.disputantSubmitedDate);
          twoDays = new Date(twoDays.setDate(createdDate.getDate() + 2));
          if (dateWithoutTime(twoDays) === dateWithoutTime(new Date())) {
            console.log('if');
            emailTemplate(settlement.workSpaceId, 'Not_Joined');
          }
        }
        if (settlement.counterPartyJoinNoOffer) {
          console.log('70');
          let counterPartyJoinNoOfferDate = new Date(
            settlement.counterPartyJoinNoOfferDate
          );
          twoDays = new Date(
            twoDays.setDate(counterPartyJoinNoOfferDate.getDate() + 2)
          );
          fourDays = new Date(
            fourDays.setDate(counterPartyJoinNoOfferDate.getDate() + 4)
          );
          sevenDays = new Date(
            sevenDays.setDate(counterPartyJoinNoOfferDate.getDate() + 7)
          );
          console.log(
            'counterPartyJoinNoOfferDate',
            counterPartyJoinNoOfferDate
          );
          console.log('twodays', twoDays);
          console.log('four days', fourDays);
          console.log('seven days', sevenDays);
          console.log(
            '81',
            dateWithoutTime(twoDays) === dateWithoutTime(new Date()),
            dateWithoutTime(fourDays) === dateWithoutTime(new Date()),
            dateWithoutTime(sevenDays) === dateWithoutTime(new Date())
          );
          if (
            dateWithoutTime(twoDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(fourDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(sevenDays) === dateWithoutTime(new Date())
          ) {
            console.log('80');
            emailTemplate(
              settlement.workSpaceId,
              'counterparty_joinded_no_offer'
            );
          }
        }
        if (settlement.disputantIsOverLap) {
          console.log('85');
          let isOverLapDate = new Date(settlement.isOverLapDate);
          twoDays = new Date(twoDays.setDate(isOverLapDate.getDate() + 2));
          fourDays = new Date(fourDays.setDate(isOverLapDate.getDate() + 4));
          sevenDays = new Date(sevenDays.setDate(isOverLapDate.getDate() + 7));
          if (
            dateWithoutTime(twoDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(fourDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(sevenDays) === dateWithoutTime(new Date())
          ) {
            console.log('95');
            emailTemplate(
              settlement.workSpaceId,
              'Counterparty_Offer_Comparison'
            );
          }
        }
        if (settlement.counterPartyIsOverLap) {
          console.log('99');
          let isOverLapDate = new Date(settlement.isOverLapDate);
          twoDays = new Date(twoDays.setDate(isOverLapDate.getDate() + 2));
          fourDays = new Date(fourDays.setDate(isOverLapDate.getDate() + 4));
          sevenDays = new Date(sevenDays.setDate(isOverLapDate.getDate() + 7));
          if (
            dateWithoutTime(twoDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(fourDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(sevenDays) === dateWithoutTime(new Date())
          ) {
            console.log('110');
            emailTemplate(settlement.workSpaceId, 'Disputant_Offer_Comparison');
          }
        }
        if (settlement.disputantOverlapSettlemetFigNotViewed) {
          console.log('115');
          let disputantOverlapSettlemetFigNotViewedDate = new Date(
            settlement.disputantOverlapSettlemetFigNotViewedDate
          );
          twoDays = new Date(
            twoDays.setDate(
              disputantOverlapSettlemetFigNotViewedDate.getDate() + 2
            )
          );
          fourDays = new Date(
            fourDays.setDate(
              disputantOverlapSettlemetFigNotViewedDate.getDate() + 4
            )
          );
          sevenDays = new Date(
            sevenDays.setDate(
              disputantOverlapSettlemetFigNotViewedDate.getDate() + 7
            )
          );
          if (
            dateWithoutTime(twoDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(fourDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(sevenDays) === dateWithoutTime(new Date())
          ) {
            console.log('125');
            emailTemplate(
              settlement.workSpaceId,
              'Counterparty_Settlement_Figure'
            );
          }
        }
        if (settlement.counterPartyOverlapSettlemetFigNotViewed) {
          console.log('130');
          let counterPartyOverlapSettlemetFigNotViewedDate = new Date(
            settlement.counterPartyOverlapSettlemetFigNotViewedDate
          );
          twoDays = new Date(
            twoDays.setDate(
              counterPartyOverlapSettlemetFigNotViewedDate.getDate() + 2
            )
          );
          fourDays = new Date(
            fourDays.setDate(
              counterPartyOverlapSettlemetFigNotViewedDate.getDate() + 4
            )
          );
          sevenDays = new Date(
            sevenDays.setDate(
              counterPartyOverlapSettlemetFigNotViewedDate.getDate() + 7
            )
          );
          if (
            dateWithoutTime(twoDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(fourDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(sevenDays) === dateWithoutTime(new Date())
          ) {
            console.log('140');
            emailTemplate(
              settlement.workSpaceId,
              'Disputant_Settlement_Figure'
            );
          }
        }
        if (settlement.disputantViewedSettlementFigNotSignAgreement) {
          console.log('145');
          let disputantViewedSettlementFigNotSignAgreementDate = new Date(
            settlement.disputantViewedSettlementFigNotSignAgreementDate
          );
          twoDays = new Date(
            twoDays.setDate(
              disputantViewedSettlementFigNotSignAgreementDate.getDate() + 2
            )
          );
          fourDays = new Date(
            fourDays.setDate(
              disputantViewedSettlementFigNotSignAgreementDate.getDate() + 4
            )
          );
          sevenDays = new Date(
            sevenDays.setDate(
              disputantViewedSettlementFigNotSignAgreementDate.getDate() + 7
            )
          );
          if (
            dateWithoutTime(twoDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(fourDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(sevenDays) === dateWithoutTime(new Date())
          ) {
            console.log('155');
            emailTemplate(
              settlement.workSpaceId,
              'Counterparty_Sign_Agreement'
            );
          }
        }
        if (settlement.counterPartyViewedSettlementFigNotSignAgreement) {
          console.log('160');
          let counterPartyViewedSettlementFigNotSignAgreementDate = new Date(
            settlement.counterPartyViewedSettlementFigNotSignAgreementDate
          );
          twoDays = new Date(
            twoDays.setDate(
              counterPartyViewedSettlementFigNotSignAgreementDate.getDate() + 2
            )
          );
          fourDays = new Date(
            fourDays.setDate(
              counterPartyViewedSettlementFigNotSignAgreementDate.getDate() + 4
            )
          );
          sevenDays = new Date(
            sevenDays.setDate(
              counterPartyViewedSettlementFigNotSignAgreementDate.getDate() + 7
            )
          );
          if (
            dateWithoutTime(twoDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(fourDays) === dateWithoutTime(new Date()) ||
            dateWithoutTime(sevenDays) === dateWithoutTime(new Date())
          ) {
            console.log('170');
            emailTemplate(settlement.workSpaceId, 'Disputant_Sign_Agreement');
          }
        }
        //  console.log(settlement);
      });
      // const newWorkspace = await Workspace.find({}, { createdAt: 1 });
      // const newTransaction = await Transaction.find({});
      // newWorkspace.forEach(async(date) => {
      //   console.log('==>', new Date(date.createdAt).getDate(), new Date().getDate());
      //   console.log('==>', new Date(date.createdAt).getMinutes() + 2 === new Date().getMinutes());
      //   if (
      //     new Date(date.createdAt).getDate() === new Date().getDate() && new Date(date.createdAt).getMinutes() + 5 === new Date().getMinutes() ) {
      //     const checkWorkspace = await Workspace.findOne({
      //       _id: date._id,
      //     });
      //     if (!checkWorkspace.counterPartyJoined) {
      //       console.log('inside if', checkWorkspace.counterPartyJoined);
      //       emailTemplate(date._id, 'Not_Joined');
      //     }
      //   }
      // });
      // newTransaction.forEach(async(date) => {
      //   console.log(
      //     new Date(date.settlementMatchFoundDate).getMinutes() + 9,
      //     new Date().getMinutes()
      //   );
      //   if ( new Date(date.settlementMatchFoundDate).getDate() === new Date().getDate() && new Date(date.settlementMatchFoundDate).getMinutes() + 5 === new Date().getMinutes()) {
      //     const checkTransaction = await Transaction.findOne({
      //       _id: date._id,
      //     });
      //     if (!checkTransaction.counterpartySettlementAgreement) {
      //       console.log(checkTransaction);
      //       emailTemplate(date.workSpaceId, 'Counterparty_Sign_Agreement');
      //     }
      //     if (!checkTransaction.disputantSettlementAgreement) {
      //       emailTemplate(date.workSpaceId, 'Disputant_Sign_Agreement');
      //     }
      //   }
      // });
      console.log('lasttttttttttt-----------------------');
    },
    // TO DO
    timeZone: 'Australia/Sydney',
    start: true,
  });
};
