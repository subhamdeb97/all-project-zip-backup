import Transaction from '../models/transaction';
import WorkSpace from '../models/workspace';
import Tracker from '../models/tracker';
import { Container } from 'typedi';
import {
  DEPENDENCY_CONTAINERS,
  ACTIVITY,
  USER_TYPE,
  RESOLVED,
} from '../../config/constants';
import { updateActivity } from './activity';
import { removeEmptyNull } from '../../utils/field_remover';
import { emailTemplate } from '../../utils/email-template';
import { redirectUrl } from '../../utils/url';
import { isNull } from 'lodash';

export const createTransaction = async(newTransaction) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    const workSpaceExist = await WorkSpace.findOne({
      _id: newTransaction.workSpaceId,
    });
    if (!workSpaceExist) {
      throw 'WorkSpace Not found';
    }
    const dispute = await removeEmptyNull(newTransaction);
    const counterParty = await removeEmptyNull(newTransaction);
    const checkTransaction = await Transaction.findOne({
      workSpaceId: newTransaction.workSpaceId,
    });

    if (dispute.disputantsettlementstatus) {
      await Tracker.findOneAndUpdate(
        {
          workSpaceId: newTransaction.workSpaceId,
        },
        {
          createWorkspaceNoOffer: false,
          disputantSubmitedDate: new Date(),
        }
      ).then((result) => {
        console.log(result);
      });
    }
    if (dispute.disputantSettlementAgreement) {
      await Tracker.findOneAndUpdate(
        {
          workSpaceId: dispute.workSpaceId,
        },
        {
          disputantViewedSettlementFigNotSignAgreement: false,
        }
      ).then(result=>{
        console.log(result);
      });
    }
    if (newTransaction.disputantShowSettlementFigure) {
      await Tracker.findOneAndUpdate(
        {
          workSpaceId: newTransaction.workSpaceId,
        },
        {
          disputantViewedSettlementFigNotSignAgreement: true,
          disputantViewedSettlementFigNotSignAgreementDate: new Date(),
        }
      );
    }
    if (counterParty.counterpartySettlementAgreement) {
      await Tracker.findOneAndUpdate(
        {
          workSpaceId: newTransaction.workSpaceId,
        },
        {
          counterPartyViewedSettlementFigNotSignAgreement: false,
        }
      );
    }
    if (newTransaction.counterPartyShowSettlementFigure) {
      await Tracker.findOneAndUpdate(
        {
          workSpaceId: newTransaction.workSpaceId,
        },
        {
          counterPartyViewedSettlementFigNotSignAgreement: true,
          counterPartyViewedSettlementFigNotSignAgreementDate: new Date(),
        }
      );
    }

    if (
      !workSpaceExist.counterPartyJoined &&
      newTransaction.disputantsettlementstatus &&
      isNull(checkTransaction)
    ) {
      await Tracker.findOneAndUpdate({
        workSpaceId: newTransaction.workSpaceId,
      }, {
        counterPartyNotJoin: true,
      });
    }
    if (
      newTransaction.disputantsettlementstatus &&
      (!checkTransaction || checkTransaction.settlementCount === 0)
    ) {
      const activity = {
        description: [ACTIVITY.DISPUTE_OFFER_SUBMIT],
        workSpaceId: newTransaction.workSpaceId,
      };
      await updateActivity(activity);
      await emailTemplate(newTransaction.workSpaceId, 'Welcome_to_Resolva');
      // await emailTemplate(newDispute.workSpaceId, 'Disputant_Submitted_Offer');
    }
    if (
      newTransaction.counterpartysettlementstatus &&
      (!checkTransaction || checkTransaction.settlementCount === 0)
    ) {
      const activity = {
        description: [ACTIVITY.COUNTERPART_OFFER_SUBMIT],
        workSpaceId: newTransaction.workSpaceId,
      };
      await updateActivity(activity);
      await Tracker.findOneAndUpdate(
        {
          workSpaceId: newTransaction.workSpaceId,
        },
        {
          counterPartyJoinNoOffer: false,
        }
      );
      // await emailTemplate(newDispute.workSpaceId, 'Counterparty_Submitted_Offer');
    }
    if (checkTransaction) {
      if (
        newTransaction.counterpartysettlementstatus &&
        checkTransaction.settlementCount === 1
      ) {
        const activity = {
          description: [ACTIVITY.RESUBMITTER_COUNTERPART_OFFER_SUBMIT],
          workSpaceId: newTransaction.workSpaceId,
        };
        await Tracker.findOneAndUpdate(
          {
            workSpaceId: newTransaction.workSpaceId,
          },
          {
            counterPartyIsOverLap: false,
          }
        );
        await updateActivity(activity);
        // await emailTemplate(newDispute.workSpaceId, 'Counterparty_Submitted_Offer');
      }
      if (
        newTransaction.disputantsettlementstatus &&
        checkTransaction.settlementCount === 1
      ) {
        const activity = {
          description: [ACTIVITY.RESUBMITTED_DISPUTE_OFFER_SUBMIT],
          workSpaceId: newTransaction.workSpaceId,
        };
        await updateActivity(activity);
        await Tracker.findOneAndUpdate(
          {
            workSpaceId: newTransaction.workSpaceId,
          },
          {
            disputantIsOverLap: false,
          }
        );
        // await emailTemplate(newDispute.workSpaceId, 'Disputant_Submitted_Offer');
      }
      if (newTransaction.role === USER_TYPE.DISPUTE) {
        await Transaction.findOneAndUpdate(
          {
            workSpaceId: newTransaction.workSpaceId,
          },
          dispute
        );
      }
      if (newTransaction.role === USER_TYPE.COUNTERPARTY) {
        await Transaction.findOneAndUpdate(
          {
            workSpaceId: newTransaction.workSpaceId,
          },
          counterParty
        );
      }

      const checkOverLap = await Transaction.findOne({
        workSpaceId: newTransaction.workSpaceId,
      });
      if (newTransaction.disputantShowSettlementFigure) {
        await Tracker.findOneAndUpdate(
          {
            workSpaceId: newTransaction.workSpaceId,
          },
          {
            disputantOverlapSettlemetFigNotViewed: false,
          }
        );
      }
      if (newTransaction.counterPartyShowSettlementFigure) {
        await Tracker.findOneAndUpdate(
          {
            workSpaceId: newTransaction.workSpaceId,
          },
          {
            counterPartyOverlapSettlemetFigNotViewed: false,
          }
        );
      }
      if (checkOverLap) {
        if (
          checkOverLap.counterpartysettlementstatus &&
          checkOverLap.disputantsettlementstatus &&
          checkOverLap.disputeCurrentSettlementValue &&
          checkOverLap.counterPartyCurrentSettlementValue
        ) {
          if (
            checkOverLap.disputeCurrentSettlementValue >
            checkOverLap.counterPartyCurrentSettlementValue
          ) {
            const activity = {
              description: [ACTIVITY.RESOLVA_NO_OVERLAP],
              workSpaceId: newTransaction.workSpaceId,
            };
            await updateActivity(activity);
            await Tracker.findOneAndUpdate(
              {
                workSpaceId: newTransaction.workSpaceId,
              },
              {
                disputantIsOverLap: true,
                counterPartyIsOverLap: true,
                isOverLapDate: new Date(),
              }
            );
            await emailTemplate(
              newTransaction.workSpaceId,
              'Counterparty_Offer_Comparison'
            );
            await emailTemplate(
              newTransaction.workSpaceId,
              'Disputant_Offer_Comparison'
            );
            if (checkOverLap.settlementCount < 2) {
              if (checkOverLap.settlementCount === 1) {
                const activityNoSettlement = {
                  description: [ACTIVITY.RESOLVA_NO_SETTLEMENT],
                  workSpaceId: newTransaction.workSpaceId,
                };
                await emailTemplate(newTransaction.workSpaceId, 'no_settlement');
                await updateActivity(activityNoSettlement);

              }
              Transaction.findOneAndUpdate(
                {
                  workSpaceId: newTransaction.workSpaceId,
                },
                {
                  settlementOverlap: null,
                  settlementCount: checkOverLap.settlementCount + 1,
                  counterpartysettlementstatus: false,
                  disputantsettlementstatus: false,
                }
              ).then((result) => result);
            }
          } else if (
            !checkOverLap.counterpartySettlementAgreement &&
            !checkOverLap.disputantSettlementAgreement &&
            checkOverLap.disputeCurrentSettlementValue <=
              checkOverLap.counterPartyCurrentSettlementValue &&
            !checkOverLap.counterpartySettlementAcceptance &&
            !checkOverLap.disputeSettlementAcceptance &&
            !checkOverLap.disputantShowSettlementFigure &&
            !checkOverLap.counterPartyShowSettlementFigure
          ) {
            const activity = {
              description: [ACTIVITY.RESOLVA_DEALFOUND],
              workSpaceId: newTransaction.workSpaceId,
            };
            let claimValue = null;
            let claimNetValue =
              (checkOverLap.disputeCurrentSettlementValue +
                checkOverLap.counterPartyCurrentSettlementValue +
                workSpaceExist.claimValue / RESOLVED.AVERAGE) /
              RESOLVED.TOTAL_AVERAGE;
            if (
              claimNetValue >= checkOverLap.disputeCurrentSettlementValue &&
              claimNetValue <= checkOverLap.counterPartyCurrentSettlementValue
            ) {
              claimValue = claimNetValue;
            } else {
              claimValue =
                (checkOverLap.disputeCurrentSettlementValue +
                  checkOverLap.counterPartyCurrentSettlementValue) /
                RESOLVED.AVERAGE;
            }
            await updateActivity(activity);
            await Tracker.findOneAndUpdate(
              {
                workSpaceId: newTransaction.workSpaceId,
              },
              {
                disputantIsOverLap: false,
                counterPartyIsOverLap: false,
              }
            );
            await Tracker.findOneAndUpdate(
              {
                workSpaceId: newTransaction.workSpaceId,
              },
              {
                disputantOverlapSettlemetFigNotViewed: true,
                disputantOverlapSettlemetFigNotViewedDate: new Date(),
              }
            );
            await Tracker.findOneAndUpdate(
              {
                workSpaceId: newTransaction.workSpaceId,
              },
              {
                counterPartyOverlapSettlemetFigNotViewed: true,
                counterPartyOverlapSettlemetFigNotViewedDate: new Date(),
              }
            );
            await emailTemplate(
              newTransaction.workSpaceId,
              'Disputant_Settlement_Figure'
            );
            await emailTemplate(
              newTransaction.workSpaceId,
              'Counterparty_Settlement_Figure'
            );
            // cronJob('* * * 2 * *', 'Counterparty_Sign_Agreement', newTransaction);
            // cronJob('* * * 2 * *', 'Disputant_Sign_Agreement', newTransaction);
            await Transaction.findOneAndUpdate(
              {
                workSpaceId: newTransaction.workSpaceId,
              },
              {
                settlementOverlap: true,
                claimValue: claimValue,
                settlementMatchFoundDate: Date.now(),
              }
            ).then((result) => result);
          }
          if (checkOverLap.disputantSettlementAgreement) {
            const activity = {
              description: [ACTIVITY.AGREEMENT_DISPUTANT],
              workSpaceId: newTransaction.workSpaceId,
            };
            await updateActivity(activity);
          }
          if (checkOverLap.counterpartySettlementAgreement) {
            const activity = {
              description: [ACTIVITY.AGREEMENT_COUNTERPARTY],
              workSpaceId: newTransaction.workSpaceId,
            };
            await updateActivity(activity);
          }
          if (checkOverLap.disputeSettlementAcceptance) {
            const activity = {
              description: [ACTIVITY.DISPUTE_OFFER_ACCEPTED],
              workSpaceId: newTransaction.workSpaceId,
            };
            await updateActivity(activity);
          }
          if (checkOverLap.counterpartySettlementAcceptance) {
            const activity = {
              description: [ACTIVITY.COUNTERPARTY_OFFER_ACCEPTED],
              workSpaceId: newTransaction.workSpaceId,
            };
            await updateActivity(activity);
          }
          if (
            checkOverLap.counterpartySettlementAcceptance &&
            checkOverLap.disputeSettlementAcceptance &&
            checkOverLap.counterpartySettlementAgreement &&
            checkOverLap.disputantSettlementAgreement
          ) {
            const activity = {
              description: [ACTIVITY.DISPUTE_RESOLVED],
              workSpaceId: newTransaction.workSpaceId,
            };
            await updateActivity(activity);
            await emailTemplate(newTransaction.workSpaceId, 'resolve_settlement');
            await emailTemplate(
              newTransaction.workSpaceId,
              'Disputant_Resolved'
            );
            await emailTemplate(
              newTransaction.workSpaceId,
              'Counterparty_Resolved'
            );
          }
          if (checkOverLap.disputantsettlementDecline) {
            const activity = {
              description: [ACTIVITY.DISPUTANT_DECLINED],
              workSpaceId: newTransaction.workSpaceId,
            };
            await updateActivity(activity);
          }
          if (checkOverLap.counterpartysettlementDecline) {
            const activity = {
              description: [ACTIVITY.COUNTERPARTY_DECLINED],
              workSpaceId: newTransaction.workSpaceId,
            };
            await updateActivity(activity);
          }
        }
      }
      const currentTransaction = await Transaction.findOne({
        workSpaceId: newTransaction.workSpaceId,
      })
        .populate('workSpaceId')
        .lean();
      currentTransaction.role = newTransaction.role.toUpperCase();
      currentTransaction.url = await redirectUrl(currentTransaction);
      return currentTransaction;
    } else {
      const transaction = new Transaction(newTransaction);
      await transaction.save();
      const currentTransaction = await Transaction.findOne({
        workSpaceId: newTransaction.workSpaceId,
      })
        .populate('workSpaceId')
        .lean();
      currentTransaction.role = newTransaction.role.toUpperCase();
      currentTransaction.url = await redirectUrl(currentTransaction);
      return currentTransaction;
    }
  } catch (err) {
    logger.error(`Error while creating Dispute ${err}`);
    throw err;
  }
};
/**
 * Functionality used to get settlement transaction to the database
 * @param {*} id newDispute object
 * @param {*} role role
 * @returns {Object} transaction data
 */
export const getTransactionByworkspaceId = async(id, role) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    const currentTransaction = await Transaction.findOne({
      workSpaceId: id,
    })
      .populate({
        path: 'workSpaceId',
        populate: {
          path: 'createdBy',
          select: '_id name email',
        },
      })
      .lean();
    if (currentTransaction) {
      currentTransaction.role = role.toUpperCase();
      currentTransaction.url = await redirectUrl(currentTransaction);
    }
    return currentTransaction;
  } catch (err) {
    logger.error(`Error while fetching user data${err}`);
    throw err;
  }
};
/**
 * Functionality used to update settlement transaction to the database
 * @param {*} newDispute newDispute object
 * @returns {Object} newDispute data
 */
export const updateDispute = async(newDispute) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    return await Transaction.findOneAndUpdate(
      {
        workSpaceId: newDispute.workSpaceId,
      },
      {
        disputeStatus: newDispute.disputeStatus,
        currentSettlementValue: newDispute.currentSettlementValue,
        previousSettlementValue: newDispute.previousSettlementValue,
        invite: newDispute.invite,
      },
      {
        new: true,
      }
    );
  } catch (err) {
    logger.error(`Error while updating the user ${err}`);
    throw err;
  }
};

module.exports = {
  createTransaction,
  getTransactionByworkspaceId,
  updateDispute,
};
