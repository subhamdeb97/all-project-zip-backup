import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS } from '../../config/constants';
import WorkSpace from '../models/workspace';
import Activity from '../models/activity';
/**
 * Functionality used to new Activity to the database
 * @param {*} activitydata activity object
 * @returns {Object} activitydata data
 */
export const createActivity = async(activitydata) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    const workSpaceExist = await WorkSpace.findOne({
      _id: activitydata.workSpaceId,
    });
    if (!workSpaceExist) {
      throw 'WorkSpace Not found';
    }
    activitydata.description[0].timestamp = Date.now();
    const activity = new Activity(activitydata);
    return await activity.save();
  } catch (err) {
    logger.error(`Error while creating activity ${err}`);
    throw err;
  }
};
/**
 * Functionality used to update Activity to the database
 * @param {*} activitydata activity object
 * @returns {Object} activitydata data
 */
export const updateActivity = async(activitydata) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    const workSpaceExist = await WorkSpace.findOne({
      _id: activitydata.workSpaceId,
    });
    if (!workSpaceExist) {
      throw 'WorkSpace Not found';
    }
    const checkactivity = await Activity.findOne({ workSpaceId: activitydata.workSpaceId}, { description: { $elemMatch: { message: activitydata.description[0].message, role: activitydata.description[0].role } } });
    if (checkactivity.description.length === 0) {
      activitydata.description[0].timestamp = Date.now();
      return await Activity.findOneAndUpdate(
        {workSpaceId: activitydata.workSpaceId },
        { $push: {description: activitydata.description[0]}}
      ).then(result =>(result));
    }
  } catch (err) {
    logger.error(`Error while creating activity ${err}`);
    throw err;
  }
};
/**
 * Functionality used to get Activity from the database
 * @param {*} activitydata activity object
 * @returns {Object} activitydata data
 */
export const getActivity = async(activitydata) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    const workSpaceExist = await WorkSpace.findOne({
      _id: activitydata.workSpaceId,
    });
    if (!workSpaceExist) {
      throw 'WorkSpace Not found';
    }
    return await Activity.findOne(
      {workSpaceId: activitydata.workSpaceId}
    ).populate({
      path: 'workSpaceId',
      populate: {
        path: 'createdBy',
        select: '_id name email'
      }
    }).then((result)=> result);
  } catch (err) {
    logger.error(`Error while creating activity ${err}`);
    throw err;
  }
};
