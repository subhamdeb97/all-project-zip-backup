import CounterParty from '../models/counterParty';
import { Container } from 'typedi';
import WorkSpace from '../models/workspace';
import { DEPENDENCY_CONTAINERS, ACTIVITY } from '../../config/constants';
// import { envelop } from '../../services/docusign/docusign';
import { updateActivity } from './activity';
import { emailTemplate } from '../../utils/email-template';
import User from '../models/user';
import Tracker from '../models/tracker';

const handleExistingUserAsCounterParty = async(id) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    const counterPartyJoined = await WorkSpace.findOneAndUpdate({
      _id: id
    }, {
      counterPartyJoined: true
    });
    await Tracker.findOneAndUpdate({
      workSpaceId: id,
    }, {
      counterPartyNotJoin: false,
      counterPartyJoinNoOffer: true,
      counterPartyJoinNoOfferDate: new Date()
    });
    await emailTemplate(id, 'Respondant_has_joined');
    const activity = {
      description: [ACTIVITY.WORKSPACE_JOINED],
      workSpaceId: id
    };
    await updateActivity(activity);
    return counterPartyJoined;
  } catch (err) {
    logger.error(`Error while creating user ${err}`);
    throw err;
  }
};

/**
 * Functionality used to create the new user to the database
 * @param {*} newUser user object
 * @param {*} id for the workspace
 * @returns {Object} newly created user data with the token
 */
export const createCounterPartyUser = async(newUser, id) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  const passwordHandler = Container.get(DEPENDENCY_CONTAINERS.PASSWORD_HANDLER);
  const tokenHandler = Container.get(DEPENDENCY_CONTAINERS.TOKEN_HANDLER);
  try {
    // Check if the workSpace exists
    const workSpaceExist = await WorkSpace.findOne({
      _id: id
    });
    if (!workSpaceExist) {
      throw 'WorkSpace Not found';
    }
    const emailExist = await WorkSpace.findOne({
      counterPartyEmail: newUser.email
    });
    if (!emailExist) {
      throw 'Email Not found';
    }
    const counterpartyExist = await CounterParty.findOne({
      email: newUser.email
    });
    const disputantExist = await User.findOne({
      email: newUser.email
    });

    if (counterpartyExist || disputantExist) {
      await handleExistingUserAsCounterParty(id);
      throw `User with email ${newUser.email} already exists`;
    }
    const counterPartyJoined = await handleExistingUserAsCounterParty(id);
    // Generate the hash
    newUser.hash = await passwordHandler.encrypt(newUser.password);
    newUser.workSpaceId = id;
    const counterParty = new CounterParty(newUser);
    const savedUser = await counterParty.save();
    // newUser.envelopeArgs.signerEmail = savedUser.email;
    // newUser.envelopeArgs.signerName = savedUser.email;
    // newUser.envelopeArgs.recipientId = savedUser._id;
    // const docusign = await envelop(newUser.envelopeArgs);
    const token = await tokenHandler.generate(savedUser);
    return {
      newUser: savedUser,
      token: token,
      // docusign: docusign,
      counterPartyJoined
    };
  } catch (err) {
    logger.error(`Error while creating user ${err}`);
    throw err;
  }
};

module.exports = {
  createCounterPartyUser
};
