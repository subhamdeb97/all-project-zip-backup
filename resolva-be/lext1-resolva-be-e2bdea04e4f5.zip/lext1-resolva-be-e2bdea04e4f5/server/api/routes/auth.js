import { Router } from 'express';
import { celebrate, Joi, errors, Segments } from 'celebrate';
import { userLogin } from '../../services/auth/login';
import { socialAuth, googleAuth } from '../../services/auth/social';
import { forgotpassword, verifyOtp } from '../../services/auth/password';
import { resetpassword } from '../../services/auth/password';
import { addUser } from '../../services/user/create';

/**
 * This is common router which will navigate the api request as per the
 * routes provided in the request url
 * @param {app} app app instance
 * @returns {router} router instance
 */
export default (app) => {
  const router = Router();

  app.use('/auth', router);

  /**
   * Route to log in using email and password
   */
  router.route('/login').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        email: Joi.string().required(),
        password: Joi.string().required(),
      }),
    }),
    userLogin
  );

  /**
   * Route to create a user
   */
  router.route('/signup').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        email: Joi.string().required(),
        password: Joi.string().required(),
        name: Joi.string().required()
      }),
    }),
    addUser
  );

  /**
   * Route to log in through 3rd party apps
   */
  router.route('/social/:platform').post(
    celebrate({
      [Segments.PARAMS]: {
        platform: Joi.string().required(),
      },
      [Segments.BODY]: Joi.object().keys({
        idToken: Joi.string().required(),
        userType: Joi.string().required(),
        role: Joi.string().required(),
        userData: Joi.object().required(),
        envelopeArgs: Joi.object().required(),
      }),
    }),
    socialAuth
  );
  /**
   * Route to log in through 3rd party apps
   */
  router.route('/login/google').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        idToken: Joi.string().required(),
      }),
    }),
    googleAuth
  );
  /**
   * Forgot password route
   */
  router.route('/password/forgot').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        email: Joi.string().required(),
      }),
    }),
    forgotpassword
  );
  /**
   * Verify OTP route
   */
  router.route('/otp/verify').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        email: Joi.string().required(),
        otp: Joi.number().required(),
        password: Joi.string().required()
      }),
    }),
    verifyOtp
  );
  /**
   * Route to reset password
   */
  router.route('/password/reset').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        email: Joi.string().required(),
        currentPassword: Joi.string().required(),
        newPassword: Joi.string().required(),
      }),
    }),
    resetpassword
  );

  app.use(errors());
};
