import { Router } from 'express';
import { celebrate, Joi, Segments } from 'celebrate';
import {crearteStripe} from '../../services/stripe/stripe';
/**
 * This is common router which will navigate the api request as per the
 * routes provided in the request url
 * @param {app} app app instance
 * @returns {router} router instance
 */
export default (app) => {
  const router = Router();

  app.use('/stripe', router);
  /**
   * Route to transfer amount from user to stripe
   */
  router.route('/').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        workSpaceId: Joi.string().required(),
        amount: Joi.number().required(),
        source: Joi.string().required(),
        role: Joi.string().required(),
        description: Joi.string().required()
      })
    }), crearteStripe
  );
};
