/* eslint-disable no-undef */
import express from 'express';
import bodyParser from 'body-parser';
import cluster from 'cluster';
import * as os from 'os';
import cors from 'cors';
import loggerIns from 'morgan';
import { Container } from 'typedi';
import { loaderInstance } from './loaders/index';
import { allowCrossDomain } from './cors';
import { connector } from './db/index';
import { DEPENDENCY_CONTAINERS } from './config/constants';
import router from './api/routes/index';
import { verifyToken } from './interceptor';
var cookieParser = require('cookie-parser');
import { cronJob } from './utils/cron_job';
loaderInstance();
let mainWorkerId = null;

const Logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
const app = express();
const constants = Container.get(DEPENDENCY_CONTAINERS.CONSTANTS);
/**
 * Functionality used to start the express server
 * @returns {express} server instance
 */
export const startExpressServer = () => {
  // This is Workers can share any TCP connection
  // It will be initialized using express
  Logger.info(`Worker ${process.pid} started`);

  app.use(loggerIns('dev')); // For dev

  app.use(bodyParser.json({ limit: constants.BODY_PARSER_LIMIT }));
  app.use(
    bodyParser.urlencoded({
      limit: constants.BODY_PARSER_LIMIT,
      extended: true,
      parameterLimit: constants.BODY_PARSER_PARAMETER_LIMIT,
    })
  );

  app.use(cookieParser());
  app.use(cors());
  // enable cors
  app.use((req, res, next) => {
    allowCrossDomain(req, res, next);
  });

  // Verify jwt token before allowing requests
  app.use(
    verifyToken.unless({
      path: constants.JWT_ALLOWED_URLS,
    })
  );

  // enable options response
  // app.options('*', cors());

  // use routes
  app.use(constants.API.PREFIX, router);

  // Server Listening
  app.listen(constants.PORT, async(err) => {
    if (err) {
      Logger.error(err);
      throw new Error(`Error while starting the server ${err}`);
    }
    Logger.info(
      `🛡️  ${constants.APP.LISTEN}${constants.PORT} AND THE WORKER ID IS ${process.pid}  🛡️`
    );
    await connector();
  });
};

if (cluster.isMaster) {
  Logger.info(`Master ${process.pid} is running`);
  const numCPUs = os.cpus().length;

  // Fork workers.
  for (let i = constants.NUMBERS.ZERO; i < numCPUs; i++) {
    cluster.fork();
  }
  // Listening to the Port to start cron
  cluster.on('listening', (worker) => {
    if (mainWorkerId === null) {
      mainWorkerId = worker.id;
      worker.send({ cronJob: 'startCron' });
    }
  });
  // Check if work id is died
  cluster.on(constants.EXIT, (worker) => {
    Logger.error(`worker ${worker.process.pid} died`);
    cluster.fork();
  });
} else {
  startExpressServer();
  // cron start
  process.on('message', function(msg) {
    if (msg.cronJob === 'startCron') {
      cronJob('0 9 * * *'); // runs 9am everyday
      // cronJob('* * * * *');
      // cronJob('*/10 * * * * *');
    }
  });
}

export default app;
