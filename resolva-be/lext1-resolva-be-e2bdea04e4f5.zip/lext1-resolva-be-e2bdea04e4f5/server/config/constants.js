import dotenv from 'dotenv';
import { isUndefined } from 'lodash';

export const ENVIRONMENT = process.env.NODE_ENV || 'LOCAL';

if (ENVIRONMENT === 'LOCAL') {
  const envFound = dotenv.config();
  if (!isUndefined(envFound.error)) {
    throw new Error('⚠️  Couldn\'t find .env file  ⚠️');
  }
} else {
  dotenv.config({
    path: '',
  });
}

export const RANDOMSTRING = {
  LENGTH: 5,
  CHARSET: 'alphanumeric',
};

export const CONSTANTS = {
  LOCAL_HOST: 'http://localhost:8081',
  PORT: 8081,
  APP: {
    LISTEN: 'MAIN SERVICE IS LISTENING TO THE PORT: ',
  },
  API: {
    PREFIX: '/api',
  },
  BODY_PARSER_LIMIT: '50mb',
  BODY_PARSER_PARAMETER_LIMIT: 5000,
  EXIT: 'exit',
  DATE_FORMAT: 'YYYY-MM-DD HH:mm:ss',
  ENV: {
    DEV: 'DEV',
    LOCAL: 'LOCAL',
  },
  NUMBERS: {
    ZERO: 0,
    ONE: 1,
    LIST: '0123456789',
    LENGTH: 6,
  },
  JWT: {
    SECRET_KEY: process.env.JWT_SECRET_KEY,
  },
  USER_SCHEMA: {
    ATTRIBUTES: ['email', 'firstName', 'lastName', 'role', 'status'],
  },
  GOOGLE_AUTH: {
    NAME: 'google',
    CLIENT_ID: process.env.GOOGLE_CLIENT_ID,
    PAYLOAD: {
      NAME: 'name',
      EMAIL: 'email',
      SUB: 'sub',
    },
  },
  FACEBOOK_AUTH: {
    NAME: 'facebook',
    CLIENT_ID: process.env.FACEBOOK_CLIENT_ID,
    CLIENT_SECRET: process.env.FACEBOOK_CLIENT_SECRET,
    ME: 'me',
    FIELDS: ['id', 'name', 'email'],
    PAYLOAD: {
      NAME: 'name',
      EMAIL: 'email',
      ID: 'id',
    },
  },
  COOKIE_OPTIONS: {
    maxAge: 604800,
    httpOnly: true,
  },
  SENDGRID: {
    API_KEY: process.env.SENDGRID_API_KEY,
    SUBJECT: 'You\'ve recently requested to reset your password',
  },

  CRYPTR_KEY: {
    SECRET: process.env.CRYPTR_KEY,
  },
  STRING_BASE_THIRTY_SIX: 36,
  GET_LAST_TEN_CHAR: -10,
  JWT_ALLOWED_URLS: [
    '/api/docusign/embedded',
    '/api/workspace/invite/',
    '/api/auth/password/forgot/',
    '/api/auth/otp/verify',
    '/api/docusign/signature',
    '/api/auth/login',
    '/api/auth/signup',
    '/api/auth/password/forgot',
    '/api/auth/password/reset',
    '/api/auth/social/facebook',
    '/api/auth/social/google',
    '/api/auth/login/google',
    { url: /^\/api\/users\/.*/ },
    { url: /^\/api\/users\/workspace\/join\/.*/ },
    { url: /^\/api\/workspace\/.*/ },
  ],
};

export const DEPENDENCY_CONTAINERS = {
  LOGGER: 'logger',
  MONGOOSE: 'Mongoose',
  USER_CONTROLLER: 'UserController',
  TOKEN_HANDLER: 'TokenHandler',
  PASSWORD_HANDLER: 'PasswordHandler',
  CONSTANTS: 'Constants',
  TRANSACTION_CONTROLLER: 'TransationController',
  COUNTERPARTY_CONTROLLER: 'CounterPartyController',
  WORKSPACE_CONTROLLER: 'WorkspaceController',
  ACTIVITY_CONTROLLER: 'ActivityController',
  BANK_CONTROLLER: 'BankController',
};

export const CORS = {
  DEV_ENVIRONMENT: 'dev',
  PROD_ENVIRONMENT: 'prod',
  QA_ENVIRONMENT: 'qa',
  ALLOWED_DOMAINS: process.env.ALLOWED_DOMAINS,
  INTERCEPT_METHOD: 'options',
  CORS_ALLOW_METHODS: 'GET, PUT, POST, PATCH, DELETE, OPTIONS',
  CREDENTIAL_STATUS: true,
  HEADERS: 'Content-Type, Authorization, Content-Length, X-Requested-With',
  CORS_REJECT: 'Request rejected',
};

export const DEPLOYMENT = {
  ENVIRONMENT: process.env.NODE_ENV,
};

export const WINSTON_CONSTS = {
  LOG_LEVEL: 'silly',
};

export const MONGO_CONSTANTS = {
  CONNECTION_ERROR: 'Error in connecting Mongo',
  CONNECTION_SUCCESSFUL: 'Successfully connected to Mongo',
  CONNECTION_DISCONNECTED: 'Mongoose default connection is disconnected',
  PROCESS_TERMIATED:
    'The Application is terminated and all the Mongoose connection to the Database is disconnected',
  DISCONNECTED: 'disconnected',
  SIGINT: 'SIGINT',
};

export const USER_TYPE = {
  DISPUTE: 'DISPUTE',
  COUNTERPARTY: 'COUNTERPARTY',
  RESOLVA: 'Resolva',
};

export const ACTIVITY = {
  WORKSPACE_CREATED: {
    role: 'DISPUTE',
    message: 'Created and joined this workspace.',
  },
  WORKSPACE_JOINED: {
    role: 'COUNTERPARTY',
    message: 'Joined this workspace.',
  },
  SUBMITTED_BANKDETAILS: {
    role: 'DISPUTE',
    message: 'Submitted payment details.',
  },
  DISPUTE_OFFER_SUBMIT: {
    role: 'DISPUTE',
    message: 'Submitted a settlement offer.',
  },
  RESUBMITTED_DISPUTE_OFFER_SUBMIT: {
    role: 'DISPUTE',
    message: 'Resubmitted a settlement offer.',
  },
  RESUBMITTER_COUNTERPART_OFFER_SUBMIT: {
    role: 'COUNTERPARTY',
    message: 'Resubmitted a settlement offer.',
  },
  RESOLVA_NO_OVERLAP: {
    role: 'Resolva',
    message: 'No settlement overlap',
  },
  RESOLVA_DEALFOUND: {
    role: 'Resolva',
    message: 'Settlement offer match found.',
  },
  COUNTERPART_OFFER_SUBMIT: {
    role: 'COUNTERPARTY',
    message: 'Submitted a settlement offer.',
  },
  AGREEMENT_DISPUTANT: {
    role: 'DISPUTE',
    message: 'Signed settlement agreement form.',
  },
  AGREEMENT_COUNTERPARTY: {
    role: 'COUNTERPARTY',
    message: 'Signed settlement agreement form.',
  },
  DISPUTE_OFFER_ACCEPTED: {
    role: 'DISPUTE',
    message: 'Settlement offer accepted.',
  },
  COUNTERPARTY_OFFER_ACCEPTED: {
    role: 'COUNTERPARTY',
    message: 'Settlement offer accepted.',
  },
  DISPUTE_RESOLVED: {
    role: 'Resolva',
    message: 'Dispute resolved.',
  },
  DISPUTE_DECLINED: {
    role: 'Resolva',
    message: 'Dispute declined.',
  },
  DISPUTANT_DECLINED: {
    role: 'DISPUTE',
    message: 'Settlement offer declined.',
  },
  COUNTERPARTY_DECLINED: {
    role: 'COUNTERPARTY',
    message: 'Settlement offer declined.',
  },
  RESOLVA_NO_SETTLEMENT: {
    role: 'Resolva',
    message: ' No Settlement.',
  },
  DISPUTE_WORKSPACE_VIEWED: {
    role: 'COUNTERPARTY',
    message: 'Workspace viewed',
  },
  DISPUTE_WORKSPACE_VIEWED_JOINED: {
    role: 'COUNTERPARTY',
    message: 'Workspace viewed & joined',
  },
};

export const TEMPLATE_ID = {
  Welcome_to_Resolva: process.env.WELCOME_TO_RESOLVA,
  Sender_Mail: 'admin@resolva.com.au',
  Send_CC: 'david.turner@lext.com.au',
  Send_Name: 'Resolva',
  Respondant_has_joined: process.env.RESPONDANT_HAS_JOINED,
  Resolved: process.env.RESOLVED,
  Sign_Agreement: process.env.SIGN_AGREEMENT,
  Offer_Comparison: process.env.OFFER_COMPARISON,
  Settlement_Figure: process.env.SETTLEMENT_FIGURE,
  Submitted_Offer: process.env.SUBMITTED_OFFER,
  Not_Joined: process.env.NOT_JOINED,
  No_offer: process.env.NO_OFFER
};

export const DOUCMENTTYPE = {
  SETTLEMEMT: 'SETTLEMENT',
};

export const RESOLVED = {
  AVERAGE: 2,
  TOTAL_AVERAGE: 3,
};


export const DISPUTE_ROUTE = {
  STEP0: { URL: '/settlement/', COMPONENT: 'settlement/' },
  STEP1: { URL: '/settlement/submitted', COMPONENT: 'submitted' },
  STEP2: {
    URL: '/settlement/unlocksettlement',
    COMPONENT: 'unlocksettlement',
  },
  STEP3: {
    URL: '/settlement/SettlementOffer',
    component: 'SettlementOffer',
  },
  STEP4: { URL: '/settlement/BankDetails', component: 'BankDetails' },
  STEP5: { URL: '/settlement/Agreement', component: 'Agreement' },
  SETTLEMENT_OVERLAP: {
    URL: '/settlement/NotSettled',
    component: 'Resolved',
  },
  SETTLEMENT_OFFER: {
    URL: '/settlement/SettlementOffer',
    component: 'SettlementOffer',
  },
  SETTLEMENT_OFFER_ACCEPTANCE: {
    URL: '/settlement/WaitingAccept',
    COMPONENT: 'WaitingAccept',
  },
  SETTLEMENT_RESOLVED: {
    URL: '/settlement/Resolved',
    component: 'Resolved',
  },
  NO_SETTLEMENT: {
    URL: '/settlement/NoSettlement',
    component: 'NoSettlement',
  },
  SETTLEMENT_DECLINE: { URL: '/settlement/Declined', component: 'Declined' },
  DISPUTANT_SETTLED: {
    URL: '/settlement/DisputantSettled',
    component: 'DisputantSettled',
  },
};
export const COUNTERPARTY_ROUTE = {
  STEP0: {
    URL: '/counterparty-workspace/',
    COMPONENT: 'counterparty-workspace/',
  },
  WAITING_SCREEN: {
    URL: '/counterparty-workspace/CounterPartySubmitted',
    component: 'CounterPartySubmitted',
  },
  STEP1: {
    URL: '/counterparty-workspace/Settled',
    component: 'Settled',
  },
  STEP2: {
    URL: '/counterparty-workspace/SettlementOffer',
    component: 'SettlementOffer',
  },
  STEP4: {
    URL: '/counterparty-workspace/Resolved',
    component: 'Resolved',
  },
  STEP5: {
    URL: '/counterparty-workspace/CounterPartyAgreement',
    component: 'CounterPartyAgreement',
  },

  NOT_SETTLED: {
    URL: '/counterparty-workspace/NotSettled',
    component: 'NotSettled',
  },
  SUBMITTED: {
    URL: '/counterparty-workspace/CounterPartySubmitted',
    component: 'CounterPartySubmitted',
  },
  SETTLEMENT_RESOLVED: {
    URL: '/counterparty-workspace/Resolved',
    component: 'Resolved',
  },
  SETTLEMENT_DECLINE: {
    URL: '/counterparty-workspace/Declined',
    component: 'Declined',
  },
  WAITING_ACCEPT: {
    URL: '/counterparty-workspace/WaitingAccept',
    component: 'WaitingAccept',
  },
  NO_SETTLEMENT: {
    URL: '/counterparty-workspace/NoSettlement',
    component: 'NoSettlement',
  },
  COUNTERPARTY_UNLOCK_SETTLEMENT: {
    URL: '/counterparty-workspace/CounterPartyUnlockSettlement',
  },
};

module.exports = {
  ENVIRONMENT,
  CONSTANTS,
  CORS,
  DEPLOYMENT,
  WINSTON_CONSTS,
  MONGO_CONSTANTS,
  DEPENDENCY_CONTAINERS,
  USER_TYPE,
  RANDOMSTRING,
  ACTIVITY,
  TEMPLATE_ID,
  DOUCMENTTYPE,
  RESOLVED,
  DISPUTE_ROUTE,
  COUNTERPARTY_ROUTE
};
