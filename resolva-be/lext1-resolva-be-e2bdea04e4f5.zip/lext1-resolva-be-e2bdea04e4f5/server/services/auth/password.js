import { OK, INTERNAL_SERVER_ERROR, NOT_FOUND } from 'http-status-codes';
import { Container } from 'typedi';
import { sendMail } from '../../utils/mailer';
import { DEPENDENCY_CONTAINERS, TEMPLATE_ID } from '../../config/constants';
import User from '../../db/models/user';
import CounterParty from '../../db/models/counterParty';

/**
 * Functionality to send new password to mail
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {String} message
 */
export const forgotpassword = async(req, res, next) => {
  try {
    const email = req.body.email;

    const passwordHandler = Container.get(
      DEPENDENCY_CONTAINERS.PASSWORD_HANDLER
    );
    const constants = Container.get(DEPENDENCY_CONTAINERS.CONSTANTS);

    const user = await User.findOne({
      email: email,
    });
    const counterParty = await CounterParty.findOne({
      email: email,
    });
    // check if user exists
    if (!user && !counterParty) {
      return res.status(NOT_FOUND).send({ message: 'User not Found' });
    }

    const otp = await passwordHandler.generateOTP();
    if (user) {
      await User.findOneAndUpdate(
        {
          email: email,
        },
        {
          otp: otp,
        }
      );
    }
    if (counterParty) {
      await CounterParty.findOneAndUpdate(
        {
          email: email,
        },
        {
          otp: otp,
        }
      );
    }
    // sending email
    const msg = {
      to: email,
      from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
      subject: constants.SENDGRID.SUBJECT,
      html: `<strong>You've recently requested to reset your password. Here's the
      OTP: ${otp} </strong>`,
    };
    const isMail = await sendMail(msg);
    if (!isMail) {
      return res.status(INTERNAL_SERVER_ERROR).send({
        message: `Error occured while sending the new password for ${email}`,
      });
    }
    return res
      .status(OK)
      .send({ message: `password has been sent to ${email}` });
  } catch (error) {
    next(error);
  }
};
/**
 * Functionality used to store new password to database
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {String} message
 */
export const resetpassword = async(req, res, next) => {
  try {
    const { email, currentPassword, newPassword } = req.body;

    const passwordHandler = Container.get(
      DEPENDENCY_CONTAINERS.PASSWORD_HANDLER
    );
    const constants = Container.get(DEPENDENCY_CONTAINERS.CONSTANTS);

    // Can't be the same
    if (currentPassword === newPassword) {
      throw 'New password and current password can\'t be the same';
    }
    const user = await User.findOne({
      email: email,
    });
    // check if user exists
    if (!user) {
      return res.status(NOT_FOUND).send({ message: 'User not found' });
    }
    // save the new password
    user.hash = await passwordHandler.encrypt(newPassword);
    await user.save();
    // sending email
    const msg = {
      to: user.email,
      from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
      subject: constants.SENDGRID.SUBJECT,
      html: `<strong>Your new password is ${newPassword} </strong>`,
    };
    await sendMail(msg);
    return res.status(OK).send({ message: 'Password has been reset.' });
  } catch (error) {
    next(error);
  }
};

/**
 * Functionality used to verify otp and save new password to database
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {String} message
 */
export const verifyOtp = async(req, res, next) => {
  const { email, otp, password } = req.body;
  const passwordHandler = Container.get(DEPENDENCY_CONTAINERS.PASSWORD_HANDLER);
  try {
    const user = await User.findOne({
      email: email,
    });
    const counterParty = await CounterParty.findOne({
      email: email,
    });
    // check if user exists
    if (!user && !counterParty) {
      return res.status(NOT_FOUND).send({ message: 'User not Found' });
    }
    if (user) {
      if (user.otp === otp) {
        user.hash = await passwordHandler.encrypt(password);
        user.otp = null;
        user.save();
        return res.status(OK).send({ message: 'Password has been reset.' });
      } else {
        return res.status(NOT_FOUND).send({ message: 'Invalid OTP' });
      }
    }
    if (counterParty) {
      if (counterParty.otp === otp) {
        counterParty.hash = await passwordHandler.encrypt(password);
        counterParty.otp = null;
        counterParty.save();
        return res.status(OK).send({ message: 'Password has been reset.' });
      } else {
        return res.status(NOT_FOUND).send({ message: 'Invalid OTP' });
      }
    }
  } catch (error) {
    next(error);
  }
};

module.exports = {
  forgotpassword,
  resetpassword,
  verifyOtp,
};
