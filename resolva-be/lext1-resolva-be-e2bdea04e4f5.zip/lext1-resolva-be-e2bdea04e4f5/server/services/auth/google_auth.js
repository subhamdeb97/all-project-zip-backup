import { CONSTANTS } from '../../config/constants';
const { OAuth2Client } = require('google-auth-library');

const GOOGLE_CLIENT_ID = CONSTANTS.GOOGLE_AUTH.CLIENT_ID;
const client = new OAuth2Client(GOOGLE_CLIENT_ID, '', '');

/**
 * Functionality used to fetch user profile from Google
 * @param {*} idToken Google token_id
 * @returns {Object} social profile
 */
export const getGoogleUser = async(idToken) => {
  try {
    const login = await client.verifyIdToken({
      idToken: idToken,
      audience: GOOGLE_CLIENT_ID
    });
    const payload = await login.getPayload();
    const audience = payload.aud;
    if (audience !== GOOGLE_CLIENT_ID) {
      throw new Error(
        'error while authenticating google user: audience mismatch: wanted [' +
          GOOGLE_CLIENT_ID +
          '] but was [' +
          audience +
          ']'
      );
    }
    return {
      firstName: payload[CONSTANTS.GOOGLE_AUTH.PAYLOAD.NAME],
      email: payload[CONSTANTS.GOOGLE_AUTH.PAYLOAD.EMAIL],
      password: String(payload[CONSTANTS.GOOGLE_AUTH.PAYLOAD.SUB])
    };
  } catch (err) {
    throw new Error(
      'error while authenticating google user: ' + JSON.stringify(err)
    );
  }
};

module.exports = {
  getGoogleUser
};
