import { CREATED, OK } from 'http-status-codes';
import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS, USER_TYPE} from '../../config/constants';


/**
 * Functionality used to create a new activity to the database
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {Object} new activity data
 */

export const createActivity = async(req, res, next) => {
  try {
    const formattedData = { ...req.body };
    const activityController = Container.get(DEPENDENCY_CONTAINERS.ACTIVITY_CONTROLLER);
    const activity = await activityController.createActivity(formattedData);
    return res.status(CREATED).send(activity);
  } catch (error) {
    next(error);
    return 'Error';
  }
};

export const updateActivity = async(req, res, next) => {
  try {
    const formattedData = { ...req.body };
    const activityController = Container.get(DEPENDENCY_CONTAINERS.ACTIVITY_CONTROLLER);
    const activity = await activityController.updateActivity(formattedData);
    return res.status(CREATED).send(activity);
  } catch (error) {
    next(error);
    return 'Error';
  }
};
export const getActivitybyId = async(req, res, next) => {
  try {
    const formattedData = { ...req.body };
    const activityController = Container.get(DEPENDENCY_CONTAINERS.ACTIVITY_CONTROLLER);
    const activitydata = await activityController.getActivity(formattedData);
    if (activitydata && req.body.role ) {
      let activity = [];
      Object.keys(activitydata.description)
        .map((index)=>{
          if (activitydata.description[index].role === USER_TYPE.DISPUTE) {
            activity.push({
              name: activitydata.workSpaceId.createdBy.name,
              activity: activitydata.description[index].role === req.body.role ? `You: ${activitydata.description[index].message}` : `${activitydata.workSpaceId.createdBy.name}: ${activitydata.description[index].message}`,
              time: new Date(activitydata.description[index].timestamp),
              currentUser: activitydata.description[index].role === req.body.role && true,
            });
          }
          if (activitydata.description[index].role === USER_TYPE.COUNTERPARTY) {
            activity.push({
              name: activitydata.workSpaceId.counterPartyName,
              activity: activitydata.description[index].role === req.body.role ? `You: ${activitydata.description[index].message}` : `${activitydata.workSpaceId.counterPartyName}: ${activitydata.description[index].message}`,
              time: new Date(activitydata.description[index].timestamp),
              currentUser: activitydata.description[index].role === req.body.role && true,
            });
          }
          if (activitydata.description[index].role === USER_TYPE.RESOLVA) {
            activity.push({
              name: USER_TYPE.RESOLVA,
              activity: `${USER_TYPE.RESOLVA}: ${activitydata.description[index].message}`,
              time: new Date(activitydata.description[index].timestamp)
            });
          }
        });
      activity.sort((fromDate, toDate)=> new Date(toDate.time) - new Date(fromDate.time));
      return res.status(CREATED).send(activity);
    } else {
      return res.status(OK).send('No Activity Found');
    }
  } catch (error) {
    next(error);
    return 'Error';
  }
};
