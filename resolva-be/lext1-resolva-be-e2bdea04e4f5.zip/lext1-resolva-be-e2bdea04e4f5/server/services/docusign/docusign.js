import docusign from 'docusign-esign';
import { DOCUSIGN_PRIVATE_KEY } from './constant';
import {
  DEPENDENCY_CONTAINERS,
  USER_TYPE,
  DOUCMENTTYPE,
} from '../../config/constants';
import {
  DOCUSIGN_TOKEN_EXPIRES,
  EMAIL_SUBJECT,
  ROLE,
  PING,
  STATUS,
  SIGNATURE,
  SIGNATURE_DATE,
  SIGNATURE_ELEMENT,
} from './signconstant';

import { fileUpload } from '../../utils/upload';
import { Container } from 'typedi';
import Workspace from '../../db/models/workspace';
import Transaction from '../../db/models/transaction';
/**
 * Functionality used to create docusign envelope
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {Object} new user data
 */

const oAuth = docusign.ApiClient.OAuth;
const restApi = docusign.ApiClient.RestApi;
const basePath = restApi.BasePath.DEMO;
const oAuthBasePath = oAuth.BasePath.DEMO;
const apiClient = new docusign.ApiClient({
  basePath: basePath,
  oAuthBasePath: oAuthBasePath,
});
const scopes = [oAuth.Scope.SIGNATURE];

/* get Auth token from docusign
 */
const authToken = async() => {
  docusign.Configuration.default.setDefaultApiClient(apiClient);
  return await apiClient
    .requestJWTUserToken(
      process.env.DOCUSIGN_CLIENT_ID,
      process.env.DOCUSIGN_USER_ID,
      scopes,
      DOCUSIGN_PRIVATE_KEY,
      DOCUSIGN_TOKEN_EXPIRES
    )
    .then((res) => res.body.access_token)
    .catch((error) => error);
};

/*  function for make envelop */

function makeEnvelope(args) {
  // create the envelope definition
  let envdef = new docusign.EnvelopeDefinition();
  envdef.emailSubject = EMAIL_SUBJECT;
  args.templateType === process.env.DOCUSIGN_TYPE
    ? (envdef.templateId = process.env.DOCUSIGN_SETTLEMENT)
    : (envdef.templateId = process.env.DOCUSIGN_CONFIDENTIAL);

  /*   Create a signer recipient to sign the document, identified by name and email
    We set the clientUserId to enable embedded signing for the recipient
    We're setting the parameters via the object creation */
  let signer = docusign.TemplateRole.constructFromObject({
    email: args.signerEmail,
    name: args.signerName,
    clientUserId: args.signerClientId,
    roleName: ROLE.SIGNER,
    recipientId: args.recipientId,
  });
  let cc = new docusign.TemplateRole();
  cc.email = args.ccEmail;
  cc.name = args.ccName;
  cc.roleName = ROLE.CC;

  /**    Create signHere fields (also known as tabs) on the documents,
   * We're using anchor (autoPlace) positioning
   * The DocuSign platform seaches throughout your envelope's
   * documents for matching anchor strings. */
  let signHere = docusign.SignHere.constructFromObject(SIGNATURE);
  let dateSignedTabs = docusign.Text.constructFromObject(SIGNATURE_DATE);

  /* For future request based requirements */
  let disputeName = SIGNATURE_ELEMENT.DISPUTANT;
  disputeName.value = args.disputeName;
  let disputantText = docusign.Text.constructFromObject(disputeName);
  let disputeAddress = SIGNATURE_ELEMENT.DISPUTANT_ADDRESS;
  disputeAddress.value = args.disputantAddress;
  let disputantAddressText = docusign.Text.constructFromObject(disputeAddress);
  let respondenName = SIGNATURE_ELEMENT.RESPONDTEXT;
  respondenName.value = args.respondenName;
  let respondenText = docusign.Text.constructFromObject(respondenName);
  let respondAddress = SIGNATURE_ELEMENT.RESPONDT_ADDRESS;
  respondAddress.value = args.respondAddress;
  let respondentAddress = docusign.Text.constructFromObject(respondAddress);
  let disputeDescription = SIGNATURE_ELEMENT.DISPUTANT_DESCRIPTION;
  disputeDescription.value = args.disputeDescription;
  let disputeBriefDescription = docusign.Text.constructFromObject(
    disputeDescription
  );
  let settleAmount = SIGNATURE_ELEMENT.SETTLEMENT_AMOUNT;
  settleAmount.value = args.settleAmount;
  let settlementAmount = docusign.Text.constructFromObject(settleAmount);
  let disputeAddressValue = SIGNATURE_ELEMENT.DISPUTANT_ADDRESS_VALUE;
  disputeAddressValue.value = args.disputantAddress;
  let disputantAddressValue = docusign.Text.constructFromObject(
    disputeAddressValue
  );
  let disputeAccountName = SIGNATURE_ELEMENT.DISPUTANT_ACC_NAME;
  disputeAccountName.value = args.accountName;
  let disputantAccName = docusign.Text.constructFromObject(disputeAccountName);
  let accountBSB = SIGNATURE_ELEMENT.DISPUTANT_BSB;
  accountBSB.value = args.accountBSB;
  let disputantBSB = docusign.Text.constructFromObject(accountBSB);
  let accoutNumber = SIGNATURE_ELEMENT.DISPUTANT_ACC_NO;
  accoutNumber.value = args.accoutNumber;
  let disputantAccNo = docusign.Text.constructFromObject(accoutNumber);
  let counterPartyDescription = SIGNATURE_ELEMENT.COUNTERPARTY_DESCRIPTION;
  counterPartyDescription.value = args.respondentDescription;
  let counterPartyIntro = docusign.Text.constructFromObject(
    counterPartyDescription
  );
  // Tabs are set per recipient / signer
  let signerTabs = docusign.Tabs.constructFromObject({
    signHereTabs: [signHere],
    textTabs: [
      disputantText,
      { disableAutoSize: true, width: '176', height: '125' },
      disputantAddressText,
      respondenText,
      respondentAddress,
      disputeBriefDescription,
      settlementAmount,
      disputantAddressValue,
      disputantAccName,
      disputantBSB,
      disputantAccNo,
      counterPartyIntro,
    ],
    dateSignedTabs: [dateSignedTabs],
  });
  signer.tabs = signerTabs;

  /**  Request that the envelope be sent by setting |status| to "sent".
   * To request that the envelope be created as a draft, set to "created" */
  envdef.status = STATUS;
  envdef.templateRoles = [signer];
  envdef.notification = docusign.Notification.constructFromObject({
    expirations: {
      expireEnabled: true,
      expireAfter: '7',
    },
  });
  return envdef;
}

/* function for making recipient view return url */

function makeRecipientViewRequest(args) {
  /*  Data for this method
    args.dsReturnUrl
    args.signerEmail
    args.signerName
    args.signerClientId
    args.dsPingUrl */

  let viewRequest = new docusign.RecipientViewRequest();

  /**   Set the url where you want the recipient to go once they are done signing
   *  should typically be a callback route somewhere in your app.
   * The query parameter is included as an example of how
   * to save/recover state information during the redirect to
   * the DocuSign signing ceremony. It's usually better to use
   * the session mechanism of your web framework. Query parameters
   * can be changed/spoofed very easily. */
  viewRequest.returnUrl = args.dsReturnUrl + '?state=' + args.recipientId;

  /**  How has your app authenticated the user? In addition to your app'sauthentication,
   *  you can include authenticate steps from DocuSign.
   * Eg, SMS authentication */
  viewRequest.authenticationMethod = 'none';

  /**   Recipient information must match embedded recipient info
   * we used to create the envelope. */
  viewRequest.email = args.signerEmail;
  viewRequest.userName = args.signerName;
  viewRequest.clientUserId = args.signerClientId;

  /**  DocuSign recommends that you redirect to DocuSign for the Signing Ceremony.
   * There are multiple ways to save state.
   * To maintain your application's session, use the pingUrl
   * parameter. It causes the DocuSign Signing Ceremony web page
   * (not the DocuSign server) to send pings via AJAX to your app, */
  viewRequest.pingFrequency = PING; // seconds
  /*  NOTE: The pings will only be sent if the pingUrl is an https address */
  viewRequest.pingUrl = args.dsPingUrl; // optional setting

  return viewRequest;
}
const worker = async(envelopeArgs, token) => {
  let dsApiClient = new docusign.ApiClient();
  dsApiClient.setBasePath(basePath);
  dsApiClient.addDefaultHeader('Authorization', 'Bearer ' + token);
  let envelopesApi = new docusign.EnvelopesApi(dsApiClient),
    results = null;

  /*  Step 1. Make the envelope request body */
  let envelope = makeEnvelope(envelopeArgs);

  /**   Step 2. call Envelopes::create API method Exceptions
   * will be caught by the calling function */
  results = await envelopesApi.createEnvelope(process.env.DOCUSIGN_ACCOUNT_ID, {
    envelopeDefinition: envelope,
  });

  let envelopeId = results.envelopeId;

  /* Step 3. create the recipient view, the Signing Ceremony */
  let viewRequest = await makeRecipientViewRequest(envelopeArgs);

  /**  Call the CreateRecipientView API
   * Exceptions will be caught by the calling function */
  results = await envelopesApi
    .createRecipientView(process.env.DOCUSIGN_ACCOUNT_ID, envelopeId, {
      recipientViewRequest: viewRequest,
    })
    .catch((error) => console.log(error));

  return { envelopeId: envelopeId, redirectUrl: results.url };
};
export const envelop = async(args, res) => {
  if (args.body) {
    args = args.body.envelopeArgs;
    const accessToken = await authToken();
    const result = await worker(args, accessToken);
    if (args.role === USER_TYPE.DISPUTE) {
      await Transaction.findOneAndUpdate(
        {
          workSpaceId: args.workSpaceId,
        },
        {
          disputantEnvelopeId: result.envelopeId,
        }
      );
    }
    if (args.role === USER_TYPE.COUNTERPARTY) {
      await Transaction.findOneAndUpdate(
        {
          workSpaceId: args.workSpaceId,
        },
        {
          counterPartyEnvelopeId: result.envelopeId,
        }
      );
    }
    res.send(result);
  }
  const accessToken = await authToken();
  return await worker(args, accessToken);
};

/* Get signature image  */
export const getsignature = async(req, res) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  let url = '';
  const accesstoken = await authToken();
  try {
    let dsApiClient = new docusign.ApiClient();
    dsApiClient.setBasePath(basePath);
    dsApiClient.addDefaultHeader('Authorization', 'Bearer ' + accesstoken);
    let envelopesApi = new docusign.EnvelopesApi(dsApiClient);
    if (req.body.type === DOUCMENTTYPE.SETTLEMEMT) {
      // call the getDocument() API
      const docuemnts = await envelopesApi.getDocument(
        process.env.DOCUSIGN_ACCOUNT_ID,
        req.body.envelopeId,
        1,
        null
      );
      if (docuemnts) {
        url = await fileUpload(docuemnts, req.body.workspaceId, req.body.type);
      }
    }
    if (req.body.role === USER_TYPE.DISPUTE) {
      await Workspace.findByIdAndUpdate(
        {
          _id: req.body.workspaceId,
        },
        {
          disputantSettlementUrl: url,
        }
      );
    }
    if (req.body.role === USER_TYPE.COUNTERPARTY) {
      await Workspace.findByIdAndUpdate(
        {
          _id: req.body.workspaceId,
        },
        {
          counterPartySettlementUrl: url,
        }
      );
    }
    return await envelopesApi
      .getRecipientSignatureImage(
        process.env.DOCUSIGN_ACCOUNT_ID,
        req.body.envelopeId,
        1,
        basePath
      )
      .then((result) =>
        res.json({
          image: result,
        })
      );
  } catch (error) {
    logger.error(`Error on getting signature ${error}`);
  }
};

/* Get Embedded URL  */
export const getEmbedded = async(req, res) => {
  const formattedData = { ...req.body };
  try {
    const workspace = await Workspace.findById({
      _id: formattedData.workspaceId,
    }).populate('createdBy');
    const envelopeArgs = {
      signerEmail: workspace.email,
      signerName: workspace.email,
      signerClientId: 1000,
      recipientId: formattedData.userId,
      dsReturnUrl: process.env.DOCUSIGN_REDIRECT_URL,
      dsPingUrl: process.env.DOCUSIGN_REDIRECT_URL,
    };
    if (formattedData.role === USER_TYPE.COUNTERPARTY) {
      envelopeArgs.signerEmail = workspace.counterPartyEmail;
      envelopeArgs.signerName = workspace.counterPartyName;
    }
    const accessToken = await authToken();
    const docusignURL = await worker(envelopeArgs, accessToken);
    res.send(docusignURL);
  } catch (error) {
    return error;
  }
};

/* Get Get envelope Info  */
export const getEnvelope = async(req, res) => {
  const envelopeId = req.params.id;
  try {
    const accessToken = await authToken();
    let dsApiClient = new docusign.ApiClient();
    dsApiClient.setBasePath(basePath);
    dsApiClient.addDefaultHeader('Authorization', 'Bearer ' + accessToken);
    let envelopesApi = new docusign.EnvelopesApi(dsApiClient),
      results = null;
    results = await envelopesApi.getEnvelope(
      process.env.DOCUSIGN_ACCOUNT_ID,
      envelopeId,
      null
    );
    res.send(results);
  } catch (error) {
    return error;
  }
};
