
# Back End Resolva

This is a Resolva project containing Node and Express with Mongo

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

To get started please install the required software in your system. Here is the list of Prerequisites

```
node >= 11.10.1
npm >= 6.13.4
```
[Mongoose](https://mongoosejs.com/docs/) - For Mongoose connection and Query Execution

### Installing

A step by step series of examples that tell you how to get a development env running

Clone the Project by the following command 

```
https://gitlink
```
Install the dependencies and dev dependencies by the following command

```
npm install
```
Once installed the necessary things, now you are ready to start the server...

# Scripts

These scripts are powered by npm commands. The project is created with the support of ES6. Hence we are converting the code with babel configuration. 

## Build
To build the project manually you can run the following command
```
npm run build
```
Please find the server scripts to play with it

## Server commands
Please find the server scripts to play with it
##### Start the local server

In the local server, we need to implement the `.env` the server will work as expected. 
```
npm run local
```

### For Linux and Mac
##### Start the dev server
```
npm run dev
```
##### Start the prod server
```
npm run prod
```
### For Windows
##### Start the dev server
```
npm run windows_dev
```
##### Start the prod server
```
npm run windows_prod
```

#Linting
To maintain the code standards we enabled he lint checks as well.
 
 ####To check Lint
 ``` 
 npm run lint
 ```
 ####To fix lint errors
 ``` 
 npm run lint:fix
 ```

## Deployment


# Contributing

When contributing to this repository, please first discuss the change you wish to make via issue,
email, or any other method with the owners of this repository before making a change. 

Please note we have a code of conduct, please follow it in all your interactions with the project.

## Pull Request Process

1. Ensure any install or build dependencies are removed before the end of the layer when doing a build.
2. Make sure your code changes do not affect the previous things
3. Update the README.md with details of changes to the interface, this includes new environment variables, exposed ports, useful file locations, and container parameters.
4. Make sure lint errors are fixed and tested with ```npm run build```
5. You may merge the Pull Request in once you have the sign-off of two other developers, or if you do not have permission to do that, you may request the second reviewer to merge it for you.

## Versioning


## License


### End


