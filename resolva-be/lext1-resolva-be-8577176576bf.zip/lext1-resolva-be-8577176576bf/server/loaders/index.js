
import dependencyInjectorLoader from './dependencyInjector';
import LoggerInstance from './logger';

/**
 * Functionality used to inject the dependencies
 * to the server
 * @returns {null} its returning null
 */
export const loaderInstance = async() => {
  try {
    await dependencyInjectorLoader();
    LoggerInstance.info('🔔 Dependency Injector loaded 🔔');
  } catch (err) {
    LoggerInstance.error('⚠️  Error on loader instance', err);
  }
};

module.exports = {
  loaderInstance
};
