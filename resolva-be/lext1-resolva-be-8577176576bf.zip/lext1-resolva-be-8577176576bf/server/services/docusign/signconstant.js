export const DOCUSIGN_TOKEN_EXPIRES = 8000;
export const EMAIL_SUBJECT = 'Please sign this document';
export const ROLE = { SIGNER: 'signer', CC: 'cc' };
export const PING = 600;
export const STATUS = 'sent';
export const SIGNATURE = {
  anchorString: '{{signHere}}',
  anchorYOffset: '10',
  anchorUnits: 'pixels',
  anchorXOffset: '20'
};
export const SIGNATURE_DATE = {
  tabLabel: 'todaysDate',
  anchorString: '{{date}}',
  anchorYOffset: '0', anchorUnits: 'pixels',
  anchorXOffset: '5'
};
export const SIGNATURE_ELEMENT = {
  DISPUTANT: {
    value: 'Disputant',
    anchorString: '{{disputant.name}}',
    anchorYOffset: '0', anchorUnits: 'pixels',
    anchorXOffset: '5'
  },
  DISPUTANT_ADDRESS: {
    value: 'DisputantAddress',
    anchorString: '{{disputant.email}}',
    anchorYOffset: '0', anchorUnits: 'pixels',
    anchorXOffset: '5'
  },
  RESPONDTEXT: {
    value: 'respondenText',
    anchorString: '{{respondent.name}}',
    anchorYOffset: '0', anchorUnits: 'pixels',
    anchorXOffset: '5'
  },
  RESPONDT_ADDRESS: {
    value: 'RespondentAddress',
    anchorString: '{{respondent.email}}',
    anchorYOffset: '0', anchorUnits: 'pixels',
    anchorXOffset: '5'
  },
  DISPUTANT_DESCRIPTION: {
    value: 'DisputeBriefDescription',
    anchorString: '{{disputant.description}}',
    anchorYOffset: '0', anchorUnits: 'pixels',
    anchorXOffset: '5'
  },
  SETTLEMENT_AMOUNT: {
    value: 'SettlementAmount',
    anchorString: '{{settlementAmount}}',
    anchorYOffset: '0', anchorUnits: 'pixels',
    anchorXOffset: '5'
  },
  DISPUTANT_ADDRESS_VALUE: {
    value: 'disputantAddress',
    anchorString: '{{disputant.email}}',
    anchorYOffset: '0', anchorUnits: 'pixels',
    anchorXOffset: '5'
  },
  DISPUTANT_ACC_NAME: {
    value: 'Disputant AccName',
    anchorString: '{{disputant.bankName}}',
    anchorYOffset: '0', anchorUnits: 'pixels',
    anchorXOffset: '5'
  },
  DISPUTANT_BSB: {
    value: 'Disputant BSB',
    anchorString: '{{disputant.BSB}}',
    anchorYOffset: '0', anchorUnits: 'pixels',
    anchorXOffset: '5'
  },
  DISPUTANT_ACC_NO: {
    value: 'Disputant AccNo',
    anchorString: '{{disputant.accNumber}}',
    anchorYOffset: '0', anchorUnits: 'pixels',
    anchorXOffset: '5'
  },
  COUNTERPARTY_DESCRIPTION: {
    value: 'counterPartyDescription',
    anchorString: '{{respondent.description}}',
    anchorYOffset: '0', anchorUnits: 'pixels',
    anchorXOffset: '5'
  }

};
