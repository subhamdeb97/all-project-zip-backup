import { CREATED, OK } from 'http-status-codes';
import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS } from '../../config/constants';

/**
 * Functionality used to create a new user to the database
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {Object} new user data
 */

export const createTransaction = async(req, res, next) => {
  try {
    const formattedData = { ...req.body };
    const transactionController = Container.get(
      DEPENDENCY_CONTAINERS.TRANSACTION_CONTROLLER
    );
    const transaction = await transactionController.createTransaction(
      formattedData
    );
    return res.status(CREATED).send({ transaction: transaction });
  } catch (error) {
    next(error);
    return 'Error';
  }
};

export const getTranactionByWorkspaceId = async(req, res, next) => {
  const id = req.params.id;
  const role = req.params.role;
  try {
    const transactionController = Container.get(
      DEPENDENCY_CONTAINERS.TRANSACTION_CONTROLLER
    );
    const transaction = await transactionController.getTransactionByworkspaceId(id, role);
    if (transaction) {
      res.status(OK).send({ transaction: transaction });
    } else {
      res.status(OK).send({ transaction: [] });
    }
  } catch (error) {
    next(error);
  }
};

export const updateDisputeDetails = async(req, res, next) => {
  try {
    const formattedData = { ...req.body };
    const transactionController = Container.get(
      DEPENDENCY_CONTAINERS.TRANSACTION_CONTROLLER
    );
    const transaction = await transactionController.updateDispute(
      formattedData
    );
    res.status(OK).send({ transaction: transaction });
  } catch (error) {
    next(error);
  }
};
