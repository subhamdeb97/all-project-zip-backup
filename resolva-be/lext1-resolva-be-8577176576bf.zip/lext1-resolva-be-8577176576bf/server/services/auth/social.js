
import { OK, UNAUTHORIZED, NON_AUTHORITATIVE_INFORMATION } from 'http-status-codes';
import { getGoogleUser } from './google_auth';
import { getFacebookUser } from './facebook_auth';
import { authenticate, socialLogin } from '../../utils/social_handler';
import Container from 'typedi';
import { DEPENDENCY_CONTAINERS } from '../../config/constants';

/**
 * Functionality used to sign up a user using 3rd part apps
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {Object} user and token
 */
export const socialAuth = async(req, res, next) => {
  try {
    const platform = req.params.platform;
    const constants = Container.get(DEPENDENCY_CONTAINERS.CONSTANTS);
    let user = {};
    let userToken = {};

    switch (platform) {
      case constants.GOOGLE_AUTH.NAME:
        user = await getGoogleUser(req.body.idToken);
        userToken = await authenticate(user, req.body.userType, req.body.userData, req.body.envelopeArgs, req.body.role)
          .catch((error)=>{
            res.status(NON_AUTHORITATIVE_INFORMATION).send({error: error});
            next(error);
          });
        break;
      case constants.FACEBOOK_AUTH.NAME:
        user = await getFacebookUser(req.body.idToken);
        userToken = await authenticate(user);
        break;
      default:
        return res.status(UNAUTHORIZED).send({message: 'Platform not supported'});
    }
    if (!userToken) {
      return res.status(UNAUTHORIZED).send({message: 'Error occured during login'});
    }
    const userData = {
      user: userToken.newUser,
      token: userToken.token,
      docusign: userToken.docusign
    };
    return res.status(OK).send(userData);
  } catch (error) {
    next(error);
  }
};
/**
 * Functionality used to login a user using 3rd part apps
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {Object} user and token
 */
export const googleAuth = async(req, res, next) => {
  const tokenHandler = Container.get(DEPENDENCY_CONTAINERS.TOKEN_HANDLER);
  try {
    let googleuser = {};
    let user = {};
    googleuser = await getGoogleUser(req.body.idToken);
    user = await socialLogin(googleuser)
      .catch((error)=>{
        res.status(NON_AUTHORITATIVE_INFORMATION).send({error: error});
        next(error);
      });

    if (!user) {
      return res.status(UNAUTHORIZED).send({message: 'Error occured during login'});
    }
    const token = await tokenHandler.generate(user);
    const userData = {
      user: user,
      token: token,
    };
    return res.status(OK).send(userData);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  socialAuth,
  googleAuth
};
