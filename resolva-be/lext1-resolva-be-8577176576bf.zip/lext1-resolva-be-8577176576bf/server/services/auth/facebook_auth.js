import { Facebook } from 'fb';
import { CONSTANTS } from '../../config/constants';

const fb = new Facebook({
  appId: CONSTANTS.FACEBOOK_AUTH.CLIENT_ID,
  appSecret: CONSTANTS.FACEBOOK_AUTH.CLIENT_SECRET
});

/**
 * Functionality used to fetch user profile from Facebook
 * @param {*} idToken Facebook access token
 * @returns {Object} social profile
 */
export const getFacebookUser = async idToken => {
  const payload = await fb.api(CONSTANTS.FACEBOOK_AUTH.ME, {
    fields: CONSTANTS.FACEBOOK_AUTH.FIELDS,
    access_token: idToken
  });
  return {
    firstName: payload[CONSTANTS.FACEBOOK_AUTH.PAYLOAD.NAME],
    email: payload[CONSTANTS.FACEBOOK_AUTH.PAYLOAD.EMAIL],
    password: String(payload[CONSTANTS.FACEBOOK_AUTH.PAYLOAD.ID])
  };
};

module.exports = {
  getFacebookUser
};
