import { OK, BAD_REQUEST } from 'http-status-codes';
// import Transaction from '../../db/models/transaction';
import Payment from '../../db/models/payment';
// import { USER_TYPE } from '../../config/constants';
var stripe = require('stripe')(process.env.STRIPE);

/**
 * Functionality used to create a new stripe to the database
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {Object} new stripe data
 */

export const crearteStripe = async(req, res, next) => {
  const source = req.body.source;
  const amount = req.body.amount;
  const description = req.body.description;

  const average = await Payment.aggregate([
    {$group: {
      '_id': null,
      'amount': { $avg: '$payment' }
    }}
  ]);

  try {
    if (amount > 1) {
      stripe.charges.create(
        {
          amount: Math.round(amount) * 100,
          currency: 'aud',
          source: source,
          description: description,
        },
        async(err, charge)=> {
          if (!err && charge.status === 'succeeded') {
            // if (req.body.role === USER_TYPE.DISPUTE) {
            //   await Transaction.findOneAndUpdate({
            //     workSpaceId: req.body.workSpaceId
            //   }, {
            //     disputantPaymentstatus: true
            //   });
            // }
            // if (req.body.role === USER_TYPE.COUNTERPARTY) {
            //   await Transaction.findOneAndUpdate({
            //     workSpaceId: req.body.workSpaceId
            //   }, {
            //     counterPartyPaymentstatus: true
            //   });
            // }
            const payment = new Payment({
              workSpaceId: req.body.workSpaceId,
              payment: amount,
              average: (average.length > 0) ? average[0].amount : 0
            });
            await payment.save();
            res.status(OK).json({
              charge: charge,
            });
          } else {
            res.status(BAD_REQUEST).send('Something went wrong during payment. Please try again with valid payment details ');
          }
        }
      );
    } else {
      res.status(BAD_REQUEST).send('Insufficient amount for transaction. Please enter a valid payment info');
    }
  } catch (error) {
    next(error);
    return 'Error';
  }
};

module.exports = {
  crearteStripe
};
