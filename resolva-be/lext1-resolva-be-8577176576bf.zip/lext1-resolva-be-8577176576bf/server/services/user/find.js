
import { OK } from 'http-status-codes';
import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS } from '../../config/constants';
import {emailTemplate} from '../../utils/email-template';

import User from '../../db/models/user';

/**
 * Functionality used to fetch a user from the database
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {object} user
 */
export const getUserDetail = async(req, res, next) => {
  try {
    const userController = Container.get(DEPENDENCY_CONTAINERS.USER_CONTROLLER);
    const id = req.cookies.id;
    const user = await userController.getUserById(id);
    res.status(OK).send({ user: user });
  } catch (error) {
    next(error);
  }
};
/**
 * Functionality used to fetch a user from the database by email
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {object} user
 */
export const getUserEmail = async(req, res, next) => {
  const email = req.params.email;
  try {
    const userController = Container.get(DEPENDENCY_CONTAINERS.USER_CONTROLLER);
    const user = await userController.getUserByEamil(email);
    res.status(OK).send({ user: user });
  } catch (error) {
    next(error);
  }
};
/**
 * Functionality used to send email from the sendGrid
 * @param {*} req request
 * @param {*} res response
 * @param {*} next middleware
 * @returns {object} user
 */

export const sendGrid = async(req, res, next) => {
  const workspace = req.params.workspaceId;
  try {
    await emailTemplate(workspace, 'Welcome_to_Resolva').then(result=>{
      res.json({result: result});
    }).catch(err=>{
      res.json({err: err});
    });

  } catch (error) {
    next(error);
  }
};

export const updateUserByEmail = async(req, res)=>{
  try {
    const body = {...req.body};
    // const userController = Container.get(DEPENDENCY_CONTAINERS.USER_CONTROLLER);
    await User.findOneAndUpdate(
      {email: body.email},
      {...body.updatedData}
    );
    res.status(OK).send({'status': 'updated'});
  } catch (err) {
    res.send(err);
  }
};

export const searchUser = async(req, res)=>{
  try {
    const email = req.params.email;
    let user = await User.findOne(
      {email: email}
    );
    res.send({user: user});
  } catch (err) {
    res.send(err);
  }
};

export const deleteUserByEmailAdmin = async(req, res)=>{
  try {
    const email = req.body.email;
    await User.findOneAndDelete(
      {email: email}
    );
    res.send({'status': 'deleted'});
  } catch (err) {
    res.send(err);
  }
};

module.exports = {
  getUserDetail,
  getUserEmail,
  sendGrid,
  updateUserByEmail,
  searchUser,
  deleteUserByEmailAdmin
};
