import { Router } from 'express';
const { celebrate, Joi, Segments } = require('celebrate');
import { createActivity, updateActivity, getActivitybyId} from '../../services/activity/activity';
/**
 * This is common router which will navigate the api request as per the
 * routes provided in the request url
 * @param {app} app app instance
 * @returns {router} router instance
 */

export default app => {
  const router = Router();
  app.use('/activity', router);
  router.route('/').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        workSpaceId: Joi.string().required(),
        description: Joi.array(),
      })
    }),
    createActivity
  );
  /**
   * Route to update activity
   */
  router.route('/update').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        workSpaceId: Joi.string().required(),
        description: Joi.array(),
      })
    }),
    updateActivity
  );
  /**
   * Route to get activity by ID
   */
  router.route('/get').post(
    celebrate({
      [Segments.BODY]: Joi.object().keys({
        workSpaceId: Joi.string().required(),
        role: Joi.string().required(),
      })
    }),
    getActivitybyId
  );
};
