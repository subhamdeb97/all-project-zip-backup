import * as jwt from 'jsonwebtoken';
import { Container } from 'typedi';
import { UNAUTHORIZED } from 'http-status-codes';
import unless from 'express-unless';
import { DEPENDENCY_CONTAINERS } from './config/constants';

/**
 * Interceptor which verifies the jwt token before allowing requests
 * @returns {Boolean} it returns a boolean value which indicates
 * the token is valid
 * @param {*} req request from the client
 * @param {*} res request to the client from server
 * @param {*} next middleware to next request
 */
export const verifyToken = async(req, res, next) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  const tokenHandler = Container.get(DEPENDENCY_CONTAINERS.TOKEN_HANDLER);
  const constants = Container.get(DEPENDENCY_CONTAINERS.CONSTANTS);
  try {
    if (!(req.headers.authorization && req.headers.id)) {
      return res.status(UNAUTHORIZED).send({ message: 'Please login to continue' });
    }
    let token = req.headers.authorization.replace(/^Bearer\s/, '');
    const id = req.headers.id;
    token = await jwt.verify(token, constants.JWT.SECRET_KEY);
    await tokenHandler.verifyUser(token, id);
    return next();
  } catch (err) {
    res.status(UNAUTHORIZED).send({ message: 'Invalid token' });
    logger.error(`Error while verifying token for user  ${err}`);
    throw err;
  }
};

verifyToken.unless = unless;

module.exports = {
  verifyToken
};
