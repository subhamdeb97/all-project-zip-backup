import { Container } from 'typedi';
import {
  DEPENDENCY_CONTAINERS,
  ACTIVITY,
  RANDOMSTRING,
  USER_TYPE,
} from '../../config/constants';
import WorkSpace from '../models/workspace';
import Activity from '../models/activity';
import User from '../models/user';
import CounterParty from '../models/counterParty';
import Mongoose from 'mongoose';
import randomstring from 'randomstring';
import Workspace from '../models/workspace';
import { createActivity, updateActivity } from './activity';
import { emailTemplate } from '../../utils/email-template';
import transaction from '../models/transaction';
import Tracker from '../models/tracker';
import { redirectUrl } from '../../utils/url';
/**
 * Functionality used to get last activity status by workspace id
 * @param {id} id workspace Id
 * @returns {Object} workspace
 */
const status = async(id) => {
  let activity = await Activity.aggregate([
    {
      $match: {
        workSpaceId: Mongoose.Types.ObjectId(id),
      },
    },
    {
      $project: {
        description: { $arrayElemAt: ['$description', -1] },
      },
    },
    {
      $project: {
        message: {
          $ifNull: ['$description.message', null],
        },
      },
    },
  ]).then((result) => result[0]);
  return activity.message;
};

/**
 * Functionality used to get workspace by workspace id
 * @param {workspaceId} workspaceId workspace Id
 * @returns {Object} workspace
 */
export const getWorkspaceById = async(workspaceId) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    if (!workspaceId) {
      throw 'Mandatory parameters missing';
    }
    const workspaceExist = await WorkSpace.findOne({
      _id: workspaceId,
    });
    if (!workspaceExist) {
      throw 'Workspace not found';
    }

    let workSpace = await WorkSpace.findOne({
      _id: workspaceId,
    })
      .populate('createdBy')
      .lean();
    workSpace.status = await status(workSpace._id).then((message) => message);

    return workSpace;
  } catch (err) {
    logger.error(`Error while fetching user data ${err}`);
    throw err;
  }
};

/**
 * Functionality used to get workspace by user id
 * @param {userId} userId user Id
 * @returns {Object} workspace
 */
export const getWorkspaceByUserId = async(userId) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    if (!userId) {
      throw 'Mandatory parameters missing';
    }
    const workspaceExist = await WorkSpace.find({
      createdBy: userId,
    }).lean();
    if (workspaceExist.length === 0) {
      throw 'Workspace not found';
    }
    let workspace = await WorkSpace.find({
      createdBy: userId,
    }).lean();
    await Promise.all(
      workspace.map(async(document) => {
        document.status = await new Promise((resolve) => {
          status(document._id).then((message) => {
            return resolve(message);
          });
        });
      })
    );
    return workspace;
  } catch (err) {
    logger.error(`Error while fetching workspace data ${err}`);
    throw err;
  }
};

/**
 * Functionality used to get workspace by email
 * @param {email} email user Id
 * @returns {Object} workspace
 */
export const getWorkspaceByEmail = async(email) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    if (!email) {
      throw 'Mandatory parameters missing';
    }
    const workspace = await WorkSpace.find({
      $or: [
        {
          $and: [{ email: email }],
        },
        {
          $and: [{ counterPartyEmail: email }],
        },
      ],
    })
      .populate('createdBy')
      .lean();
    await Promise.all(
      workspace.map(async(document) => {
        document.status = await new Promise((resolve) => {
          status(document._id).then((message) => {
            return resolve(message);
          });
        });
      })
    );
    return workspace;
  } catch (err) {
    logger.error(`Error while fetching workspace data ${err}`);
    throw err;
  }
};

/**
 * Functionality to unsubscribe
 * @param {workspaceId} workspaceId Id
 * @param {unsubscribe} unsubscribeValue unsubscribe
 * @returns {Object} workspace
 */

export const unsubscribe = async(workspaceId) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    if (!workspaceId) {
      throw 'Mandatory parameters missing';
    }
    const workspaceExist = await WorkSpace.findById({
      _id: workspaceId,
    });
    if (!workspaceExist) {
      throw 'Workspace not found';
    }
    if (workspaceExist.isCounterpartyUnsubscribed) {
      throw 'You\'ve already unsubscribed!';
    }
    return WorkSpace.findByIdAndUpdate(
      {
        _id: workspaceId,
      },
      {
        isCounterpartyUnsubscribed: true,
      }
    );
  } catch (err) {
    logger.error(`Error while fetching workspace data ${err}`);
    throw err;
  }
};

/**
 * Functionality to check invite Status
 * @param {workspaceId} workspaceId Id
 * @param {role} role role
 * @returns {Object} workspace
 */
export const inviteStatus = async(workspaceId, role) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    if (!workspaceId) {
      throw 'Mandatory parameters missing';
    }
    const workspaceExist = await WorkSpace.findById({
      _id: workspaceId,
    });
    if (!workspaceExist) {
      throw 'Workspace not found';
    }
    const workspace = await transaction
      .findOne({
        workSpaceId: workspaceId,
      })
      .populate('workSpaceId')
      .lean();
    if (!workspace) {
      const workspaceData = {};
      workspaceData.workSpaceId = await WorkSpace.findById({
        _id: workspaceId,
      });
      workspaceData.role = role.toUpperCase();
      workspaceData.url = await redirectUrl(workspaceData);
      return workspaceData;
    }
    workspace.role = role.toUpperCase();
    workspace.url = await redirectUrl(workspace);
    return workspace;
  } catch (err) {
    logger.error(`Error while fetching workspace data ${err}`);
    throw err;
  }
};

/**
 * Functionality used to update workspace by  id
 * @param {workspaceId} workspaceId workspace Id
 * @param {workspaceData} workspaceData workspace Id
 * @returns {Object} workspace
 */
export const updateWorkspaceById = async(workspaceId, workspaceData) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    if (!workspaceId) {
      throw 'Mandatory parameters missing';
    }
    const workspaceExist = await WorkSpace.findById({
      _id: workspaceId,
    }).lean();
    if (!workspaceExist) {
      throw 'Workspace not found';
    }
    const workspace = {
      businessName: workspaceData.businessName,
      introduction: workspaceData.introduction,
      days: workspaceData.days,
      counterPartyName: workspaceData.counterPartyName,
      counterPartyBussiness: workspaceData.counterPartyBussiness,
      counterPartyEmail: workspaceData.counterPartyEmail,
    };
    await Workspace.findByIdAndUpdate(
      {
        _id: workspaceId,
      },
      workspace
    );
    await User.findOneAndUpdate(
      {
        email: workspaceExist.email,
      },
      {
        email: workspaceData.email,
        name: workspaceData.disputantName,
      }
    );
    let currentWorkspace = await Workspace.find({
      email: workspaceExist.email,
    })
      .select('_id')
      .lean();

    await Promise.all(
      currentWorkspace.map(async(document) => {
        await Workspace.findByIdAndUpdate(
          {
            _id: document._id,
          },
          {
            email: workspaceData.email,
          }
        );
      })
    );
    return await WorkSpace.findById({
      _id: workspaceId,
    }).lean();
  } catch (err) {
    logger.error(`Error while fetching user data ${err}`);
    throw err;
  }
};

const createTracker = async(saveWorkspace) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    const trackerExist = await Tracker.findOne({
      workSpaceId: saveWorkspace._id,
    });
    // update if already exist
    if (trackerExist) {
      await Tracker.findOneAndUpdate(
        {
          workSpaceId: saveWorkspace._id,
        },
        {
          createWorkspaceNoOffer: true,
        }
      );
    }
    // else save it new
    const trackerdata = {
      workSpaceId: saveWorkspace._id,
      createWorkspaceNoOffer: true,
    };
    const tracker = new Tracker(trackerdata);
    await tracker.save();
  } catch (err) {
    logger.error(`Error while creating tracker ${err}`);
    throw err;
  }
};

/**
 * Functionality used to create workspace
 * @param {workspaceData} workspaceData workspace data
 * @returns {Object} workspace
 */
export const createWorkspace = async(workspaceData) => {
  const tokenHandler = Container.get(DEPENDENCY_CONTAINERS.TOKEN_HANDLER);
  const disputeId = randomstring.generate({
    length: RANDOMSTRING.LENGTH,
    charset: RANDOMSTRING.CHARSET,
  });

  const userExist = await User.findOne({
    email: workspaceData.email,
  });
  if (userExist) {
    workspaceData.disputeId = `#${disputeId.toUpperCase()}`;
    workspaceData.createdBy = workspaceData.id;
    const workspace = new Workspace(workspaceData);
    const saveWorkspace = await workspace.save();
    await User.findOneAndUpdate(
      {
        email: workspaceData.email,
      },
      {
        name: workspaceData.disputantName,
      }
    );
    // await emailTemplate(saveWorkspace._id, 'Welcome_to_Resolva');
    const activity = {
      description: [ACTIVITY.WORKSPACE_CREATED],
      workSpaceId: saveWorkspace._id,
    };
    await createActivity(activity);
    await createTracker(saveWorkspace);
    // for feature use
    // workspaceData.envelopeArgs.signerEmail = userExist.email;
    // workspaceData.envelopeArgs.signerName = userExist.email;
    // workspaceData.envelopeArgs.recipientId = userExist._id;
    // let docusign;
    // await envelop(workspaceData.envelopeArgs).then((result) => {
    //   docusign = result;
    // });
    userExist.workSpaceId = saveWorkspace._id;
    const token = await tokenHandler.generate(userExist);
    return {
      newUser: userExist,
      token: token,
      workspaceId: saveWorkspace._id
      // docusign: docusign,
    };
  }
  const counterParty = await CounterParty.findOne({
    email: workspaceData.email,
  });

  // create a new counter party record and link it to the workspace
  if (counterParty) {
    workspaceData.disputeId = `#${disputeId.toUpperCase()}`;
    workspaceData.createdBy = workspaceData.id;
    const workspace = new Workspace(workspaceData);
    const saveWorkspace = await workspace.save();
    const userData = {
      workSpaceId: saveWorkspace._id,
      name: workspaceData.disputantName,
      email: workspaceData.email,
      role: USER_TYPE.DISPUTE,
      hash: counterParty.hash,
    };
    const user = new User(userData);
    const savedUser = await user.save().then((userSaveData) => {
      return Workspace.findByIdAndUpdate(
        {
          _id: saveWorkspace._id,
        },
        {
          createdBy: userSaveData._id,
        }
      ).then(() => {
        return user;
      });
    });
    const activity = {
      description: [ACTIVITY.WORKSPACE_CREATED],
      workSpaceId: saveWorkspace._id,
    };
    await createActivity(activity);
    await createTracker(saveWorkspace);
    // await emailTemplate(saveWorkspace._id, 'Welcome_to_Resolva');
    workspaceData.envelopeArgs.signerEmail = counterParty.email;
    workspaceData.envelopeArgs.signerName = counterParty.disputantName;
    workspaceData.envelopeArgs.recipientId = counterParty._id;
    // let docusign;
    // await envelop(workspaceData.envelopeArgs).then((result) => {
    //   docusign = result;
    // });
    savedUser.workSpaceId = saveWorkspace._id;
    const token = await tokenHandler.generate(savedUser);
    return {
      newUser: savedUser,
      token: token,
      // docusign: docusign,
    };
  }
};
/**
 * Functionality used to update status in the workspace
 * @param {workspaceId} workspaceId workspace id
 * @param {workspaceData} workspaceData workspaceData
 * @returns {Object} workspace
 */
export const updateStatus = async(workspaceId, workspaceData) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    if (!workspaceId) {
      throw 'Mandatory parameters missing';
    }
    const workspaceExist = await WorkSpace.find({
      _id: workspaceId,
    }).lean();
    if (!workspaceExist) {
      throw 'Workspace not found';
    }
    if (workspaceData.disputantConfidentiality) {
      await WorkSpace.findByIdAndUpdate(
        {
          _id: workspaceId,
        },
        {
          disputantConfidentiality: workspaceData.disputantConfidentiality,
        }
      );
    }
    if (workspaceData.counterPartyConfidentiality) {
      await WorkSpace.findByIdAndUpdate(
        {
          _id: workspaceId,
        },
        {
          counterPartyConfidentiality:
            workspaceData.counterPartyConfidentiality,
        }
      );
      //  when counterParty checked Confidentiality
      await emailTemplate(workspaceId, 'Respondant_has_joined');
    }
    const workspace = {
      counterPartyViewed: workspaceData.counterPartyViewed,
    };
    if (workspaceData.viewedAndJoined) {
      const activity = {
        description: [ACTIVITY.DISPUTE_WORKSPACE_VIEWED],
        workSpaceId: workspaceId,
      };
      const Joinedactivity = {
        description: [ACTIVITY.WORKSPACE_JOINED],
        workSpaceId: workspaceId,
      };
      await updateActivity(activity);
      await updateActivity(Joinedactivity);
      const counterPartyJoined = {
        counterPartyJoined: workspaceData.counterPartyJoined,
      };
      await Tracker.findOneAndUpdate(
        {
          workSpaceId: workspaceId,
        },
        {
          counterPartyNotJoin: false,
          counterPartyJoinNoOffer: true,
          counterPartyJoinNoOfferDate: new Date(),
        }
      );
      await WorkSpace.findByIdAndUpdate(
        {
          _id: workspaceId,
        },
        counterPartyJoined
      ).lean();
    } else if (
      !workspaceData.viewedAndJoined &&
      workspaceData.counterPartyViewed
    ) {
      const activity = {
        description: [ACTIVITY.DISPUTE_WORKSPACE_VIEWED],
        workSpaceId: workspaceId,
      };
      await updateActivity(activity);
    }
    if (workspaceData.counterPartyViewed) {
      return await WorkSpace.findByIdAndUpdate(
        {
          _id: workspaceId,
        },
        workspace
      ).lean();
    }
    return await Workspace.findById({
      _id: workspaceId,
    }).lean();
  } catch (err) {
    logger.error(`Error while updating status ${err}`);
    throw err;
  }
};

/**
 * Functionality used to update the workspace
 * @param {workspaceId} workspaceId workspace id
 * @param {workspaceData} workspaceData workspaceData
 * @returns {Object} workspace
 */
export const updateWorkspace = async(workspaceId, workspaceData) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    if (!workspaceId) {
      throw 'Mandatory parameters missing';
    }
    const workspaceExist = await WorkSpace.find({
      _id: workspaceId,
    }).lean();
    if (!workspaceExist) {
      throw 'Workspace not found';
    }
    await WorkSpace.update(
      {
        _id: workspaceId,
      },
      {
        $set: workspaceData,
      }
    );
    const workspace = await WorkSpace.findById(workspaceId);
    return workspace;
  } catch (error) {
    logger.error(`Error while updating status ${error}`);
    throw error;
  }
};
