import User from '../models/user';
import Tracker from '../models/tracker';
import CounterParty from '../models/counterParty';
import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS, RANDOMSTRING, ACTIVITY } from '../../config/constants';
// import {emailTemplate} from '../../utils/email-template';
import Workspace from '../models/workspace';
// import { envelop } from '../../services/docusign/docusign';
import { createActivity } from './activity';
import randomstring from 'randomstring';
// import {cronJob} from '../../utils/cron_job';


const createTracker = async(saveWorkspace) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    const trackerExist = await Tracker.findOne({
      workSpaceId: saveWorkspace._id
    });
    // update if already exist
    if (trackerExist) {
      await Tracker.findOneAndUpdate({
        workSpaceId: saveWorkspace._id
      }, {
        createWorkspaceNoOffer: true,
      });
    }
    // else save it new
    const trackerdata = {
      workSpaceId: saveWorkspace._id,
      createWorkspaceNoOffer: true,
    };
    const tracker = new Tracker(trackerdata);
    await tracker.save();
  } catch (err) {
    logger.error(`Error while creating tracker ${err}`);
    throw err;
  }
};

/**
 * Functionality used to create the new user to the database
 * @param {*} newUser user object
 * @param {*} url for host name to send invite link
 * @returns {Object} newly created user data with the token
 */
// , url for sendgrid
export const createUser = async(newUser) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  const passwordHandler = Container.get(DEPENDENCY_CONTAINERS.PASSWORD_HANDLER);
  const tokenHandler = Container.get(DEPENDENCY_CONTAINERS.TOKEN_HANDLER);

  try {
    // Check if the user exists
    const userExist = await User.findOne({email: newUser.email});
    if (userExist) {
      throw `User with email ${newUser.email} already exists`;
    }

    const userData = {
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
      hash: await passwordHandler.encrypt(newUser.password),
    };

    const user = new User(userData);
    const savedUser = await user.save();
    const token = await tokenHandler.generate(savedUser);
    return {
      newUser: savedUser,
      token: token,
    };
  } catch (err) {
    logger.error(`Error while creating user ${err}`);
    throw err;
  }
};

/**
 * Functionality used to get the list of available users
 * from the database
 * @returns {Array} user list
 */
export const getUsers = async() => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    return await User.find();
  } catch (err) {
    logger.error(`Error while getting the users list ${err}`);
    throw err;
  }
};

/**
 * Functionality used to get the details of a particular user
 * from the database
 * @param {*} email user unique id value
 * @returns {Object} user
 */
export const getUserByEamil = async(email) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    if (!email) {
      throw 'Mandatory parameters missing';
    }

    const user = await User.findOne({
      email: email
    })
      .select('-hash')
      .lean();
    if (user) {
      const workspace = await Workspace.findOne({
        createdBy: user._id
      }).lean();
      const userInfo = {};
      userInfo.user = user;
      userInfo.workspace = workspace;
      return userInfo;
    } else {
      return [];
    }
  } catch (err) {
    logger.error(`Error while fetching user data ${err}`);
    throw err;
  }
};

/**
 * Functionality used to fetch a user object
 * from the database using email
 * @param {email} email user email
 * @returns {Object} user
 */
export const findUserByEmail = async(email) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    const user = await User.findOne({
      email: email
    });
    const counterParty = await CounterParty.findOne({
      email: email,
    }).lean();
    if (user) {
      return user;
    }
    if (counterParty) {
      return counterParty;
    }
  } catch (err) {
    logger.error(`Error while fetching user data${err}`);
    throw err;
  }
};
/**
 * Functionality used to fetch a user object
 * from the database using userId
 * @param {userId} userId user userId
 * @returns {Object} user
 */
export const getUserById = async(userId) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    if (!userId) {
      throw 'Mandatory parameters missing';
    }

    return await User.findOne({
      _id: userId
    })
      .lean();
  } catch (err) {
    logger.error(`Error while fetching user data ${err}`);
    throw err;
  }
};

module.exports = {
  createUser,
  getUsers,
  getUserByEamil,
  getUserById,
  findUserByEmail
};
