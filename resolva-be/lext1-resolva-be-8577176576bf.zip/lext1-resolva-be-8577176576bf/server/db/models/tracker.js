import * as mongoose from 'mongoose';
const Schema = mongoose.Schema;
/**
 * offerSubmissionTracker model design.
 * @returns {mongooseModel} it returns the schema model of offerSubmissionTracker
 */

const offerSubmissionTracker = new Schema(
  {
    workSpaceId: {
      type: Schema.Types.ObjectId,
      ref: 'Workspace',
      required: true,
    },
    createWorkspaceNoOffer: {
      type: Boolean,
      default: false
    },
    counterPartyNotJoin: {
      type: Boolean,
      default: false,
    },
    counterPartyJoinNoOffer: {
      type: Boolean,
      default: false,
    },
    disputantIsOverLap: {
      type: Boolean,
      default: false,
    },
    counterPartyIsOverLap: {
      type: Boolean,
      default: false,
    },
    disputantOverlapSettlemetFigNotViewed: {
      type: Boolean,
      default: false
    },
    counterPartyOverlapSettlemetFigNotViewed: {
      type: Boolean,
      default: false
    },
    disputantViewedSettlementFigNotSignAgreement: {
      type: Boolean,
      default: false
    },
    counterPartyViewedSettlementFigNotSignAgreement: {
      type: Boolean,
      default: false
    },
    counterPartyJoinNoOfferDate: {
      type: Date
    },
    isOverLapDate: {
      type: Date
    },
    disputantOverlapSettlemetFigNotViewedDate: {
      type: Date
    },
    counterPartyOverlapSettlemetFigNotViewedDate: {
      type: Date
    },
    disputantViewedSettlementFigNotSignAgreementDate: {
      type: Date
    },
    counterPartyViewedSettlementFigNotSignAgreementDate: {
      type: Date
    },
    disputantSubmitedDate: {
      type: Date
    }
  },
  { timestamps: true }
);
export default mongoose.model('offerSubmissionTracker', offerSubmissionTracker);
