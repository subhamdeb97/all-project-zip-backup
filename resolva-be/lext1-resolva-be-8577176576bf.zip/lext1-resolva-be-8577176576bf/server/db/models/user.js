import { DataBrew } from 'aws-sdk';
import * as mongoose from 'mongoose';
const Schema = mongoose.Schema;

/**
 * User model design for dispute.
 * @returns {mongooseModel} it returns the schema model for dispute user
 */
const user = new Schema({
  // workSpaceId: {
  //   type: Schema.Types.ObjectId,
  //   ref: 'Workspace'
  // },
  email: {
    type: String,
    required: [true, 'can\'t be blank'],
  },
  name: {
    type: String,
    required: [true, 'can\'t be blank'],
  },
  hash: {
    type: String,
  },
  role: {
    type: String,
    // required: [true, 'can\'t be blank'],
  },
  otp: {
    type: Number
  },


  ABN: {
    type: String
  },
  address: {
    type: String
  },
  businessName: {
    type: String
  },
  city: {
    type: String
  },
  postalCode: {
    type: String
  },
  state: {
    type: String
  },
  mobile: {
    type: String
  },
  userRole: {
    type: String
  }

},
{timestamps: true});

user.index({
  email: 1,
}, {
  unique: true
});

export default mongoose.model('User', user);
