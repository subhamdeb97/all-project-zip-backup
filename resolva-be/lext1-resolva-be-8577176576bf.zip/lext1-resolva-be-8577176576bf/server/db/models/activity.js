import * as mongoose from 'mongoose';
const Schema = mongoose.Schema;
/**
 * activity model design.
 * @returns {mongooseModel} it returns the schema model of activity
 */

const activity = new Schema({
  workSpaceId: {
    type: Schema.Types.ObjectId,
    ref: 'Workspace',
    required: true,
  },
  description: {
    type: Array,
    required: true,
  },
}, { timestamps: true });
export default mongoose.model('Activity', activity);
