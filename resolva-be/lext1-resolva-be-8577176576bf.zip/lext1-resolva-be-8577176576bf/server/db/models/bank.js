import * as mongoose from 'mongoose';
const Schema = mongoose.Schema;

/**
 * Bank model design.
 * @returns {mongooseModel} it returns the schema model of bank details
 */

const bank = new Schema({
  workSpaceId: {
    type: Schema.Types.ObjectId,
    ref: 'Workspace',
    index: true
  },
  name: {
    type: String,
    required: [true, 'can\'t be blank'],
  },
  bsb: {
    type: String,
    required: [true, 'can\'t be blank'],
  },
  accountNumber: {
    type: String,
    required: [true, 'can\'t be blank'],
  },
}, { timestamps: true });


export default mongoose.model('Bank', bank);
