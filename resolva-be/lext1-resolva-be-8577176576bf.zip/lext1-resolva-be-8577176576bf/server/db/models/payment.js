import * as mongoose from 'mongoose';
const Schema = mongoose.Schema;
/**
 * average payment model design.
 * @returns {mongooseModel} it returns the schema model of payment
 */

const payment = new Schema(
  {
    workSpaceId: {
      type: Schema.Types.ObjectId,
      ref: 'Workspace',
      required: true,
    },
    payment: {
      type: Number,
      required: true,
    },
    average: {
      type: Number,
      required: true,
    },
  },
  { timestamps: true }
);
export default mongoose.model('Payment', payment);
