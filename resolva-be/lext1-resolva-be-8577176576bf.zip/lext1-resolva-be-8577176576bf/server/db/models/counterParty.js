import * as mongoose from 'mongoose';
const Schema = mongoose.Schema;

/**
 * User model design.
 * @returns {mongooseModel} it returns the schema model of counterParty
 */

const counterParty = new Schema({
  workSpaceId: {
    type: Schema.Types.ObjectId,
    ref: 'Workspace',
    unique: true,
    required: true,
    index: true,
    dropDups: true
  },
  email: {
    type: String,
    required: [true, 'can\'t be blank'],
  },
  hash: {
    type: String,
  },
  role: {
    type: String,
    required: [true, 'can\'t be blank'],
  },
  otp: {
    type: Number
  }
}, { timestamps: true });
export default mongoose.model('CounterParty', counterParty);
