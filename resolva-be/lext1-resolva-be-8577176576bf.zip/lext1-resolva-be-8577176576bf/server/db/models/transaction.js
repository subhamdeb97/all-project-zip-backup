import * as mongoose from 'mongoose';
const Schema = mongoose.Schema;

/**
 * User model design.
 * @returns {mongooseModel} it returns the schema model of transaction
 */

const transaction = new Schema({
  workSpaceId: {
    type: Schema.Types.ObjectId,
    ref: 'Workspace',
    index: true
  },
  disputantPaymentstatus: {
    type: Boolean,
    default: false
  },
  counterPartyPaymentstatus: {
    type: Boolean,
    default: false
  },
  bankDetails: {
    type: Boolean,
    default: false
  },
  disputantsettlementstatus: {
    type: Boolean,
    default: false
  },
  disputantsettlementDecline: {
    type: Boolean,
    default: false
  },
  counterpartysettlementDecline: {
    type: Boolean,
    default: false
  },
  disputantSettlementAgreement: {
    type: Boolean,
    default: false
  },
  counterpartySettlementAgreement: {
    type: Boolean,
    default: false
  },
  counterpartysettlementstatus: {
    type: Boolean,
    default: false
  },
  disputeSettlementAcceptance: {
    type: Boolean,
    default: false
  },
  counterpartySettlementAcceptance: {
    type: Boolean,
    default: false
  },
  settlementOverlap: {
    type: Boolean,
    default: false
  },
  disputeCurrentSettlementValue: {
    type: Number
  },
  disputePreviousSettlementValue: {
    type: Number
  },
  counterPartyCurrentSettlementValue: {
    type: Number
  },
  counterPartyPreviousSettlementValue: {
    type: Number
  },
  settlementCount: {
    type: Number,
    default: 0
  },
  settlementMatchFoundDate: {
    type: Date,
  },
  counterPartyShowSettlementFigure: {
    type: Boolean,
    default: false
  },
  disputantShowSettlementFigure: {
    type: Boolean,
    default: false
  },
  claimValue: {
    type: Number,
    default: 0
  },
  disputantEnvelopeId: {
    type: String,
  },
  counterPartyEnvelopeId: {
    type: String,
  }

}, { timestamps: true });

export default mongoose.model('Transaction', transaction);
