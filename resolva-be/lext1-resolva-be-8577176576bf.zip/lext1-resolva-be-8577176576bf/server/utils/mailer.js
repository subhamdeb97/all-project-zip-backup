import sgMail from '@sendgrid/mail';
import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS, TEMPLATE_ID } from '../config/constants';

/**
 * Functionality used to send mail using sendgrid
 * @param {*} msg message to be sent in the email
 * @returns {Boolean} true or false
 */
export const sendMail = async(msg) => {
  const constants = Container.get(DEPENDENCY_CONTAINERS.CONSTANTS);
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    sgMail.setApiKey(constants.SENDGRID.API_KEY);
    sgMail.setSubstitutionWrappers('{{', '}}');
    msg.bcc = TEMPLATE_ID.Send_CC;
    await sgMail.send(msg).then(resut => {
      console.log('result');
    }).catch(err => {
      console.log('Sendgrid error');
    });
    return true;
  } catch (err) {
    logger.error(`Error while sending mail for resetting password ${err}`);
    throw err;
  }
};
