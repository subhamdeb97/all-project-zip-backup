import WorkSpace from '../db/models/workspace';
import { sendMail } from './mailer';
import { DEPENDENCY_CONTAINERS, TEMPLATE_ID } from '../config/constants';
import { Container } from 'typedi';

/**
 * Functionality for Sendgrid template
 * @param {id} id workspace Id
 * @param {template} template template name
 * @returns {object} sendgrid mail
 */
export const emailTemplate = async(id, template) => {
  console.log('on email template');
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  const workspace = await WorkSpace.findById({
    _id: id,
  })
    .populate('createdBy')
    .lean();
  try {
    let link = (workspace.counterPartyJoined) ? `workspace/activity/counterparty/track/${id}` : `workspace/join/${workspace._id}`;
    let message;
    switch (template) {
      case 'Welcome_to_Resolva':
        if (!workspace.isCounterpartyUnsubscribed) {
          message = {
            to: workspace.counterPartyEmail,
            from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
            templateId: TEMPLATE_ID.Welcome_to_Resolva,
            dynamic_template_data: {
              subject: `${workspace.createdBy.name} has made an offer to settle your dispute on Resolva`,
              disputantName: workspace.createdBy.name,
              unsubscribe: `<a href='${process.env.HOST_NAME}/unsubscribe/counterparty/workspace/${workspace._id}'>unsubscribe</a>`,
              inviteLink: `<a href='${process.env.HOST_NAME}/workspace/join/${workspace._id}'>here</a>`,
              makeOffer: `<a href="${process.env.HOST_NAME}/workspace/join/${workspace._id}" style="border:1px solid #17CAE8; border-color:#17CAE8; border-radius:6px; border-width:1px; color:#ffffff; display:inline-block; font-size:14px; font-weight:bold; letter-spacing:0px; line-height:normal; padding:12px 18px 12px 18px; text-align:center; text-decoration:none; border-style:solid; background-color:#17cae8;" target="_blank">Make an offer</a>`,
              description: workspace.introduction,
            },
          };
          await sendMail(message);
        }
        break;
      case 'Respondant_has_joined':
        message = {
          to: workspace.createdBy.email,
          from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
          templateId: TEMPLATE_ID.Respondant_has_joined,
          dynamic_template_data: {
            subject: 'Update on your dispute',
            respondentName: workspace.counterPartyName,
            unsubscribe: `<a href='${process.env.HOST_NAME}/unsubscribe/counterparty/workspace/${workspace._id}'>unsubscribe</a>`,
            inviteLink: `<a href='${process.env.HOST_NAME}/workspace/activity/dispute/track/${id}'>here</a>`
          },
        };
        await sendMail(message);
        break;
      case 'Not_Joined':
        console.log('not join template');
        if (!workspace.isCounterpartyUnsubscribed) {
          message = {
            to: workspace.counterPartyEmail,
            from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
            templateId: TEMPLATE_ID.Not_Joined,
            dynamic_template_data: {
              subject: `${workspace.createdBy.name} is waiting for you to join `,
              disputantName: workspace.createdBy.name,
              Link: `<a href='${process.env.HOST_NAME}/workspace/join/${workspace._id}'>here</a>`,
              unsubscribe: `<a href='${process.env.HOST_NAME}/unsubscribe/counterparty/workspace/${workspace._id}'>unsubscribe</a>`,
              description: workspace.introduction,
            },
          };
          await sendMail(message);
        }
        break;
      case 'Counterparty_Submitted_Offer':
        message = {
          to: workspace.createdBy.email,
          from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
          templateId: TEMPLATE_ID.Submitted_Offer,
          dynamic_template_data: {
            action: 'joined',
            subject: `Your dispute with ${workspace.counterPartyName} – submit your best offer`,
            partyName: workspace.counterPartyName,
            description: workspace.introduction,
            Link: `<a href='${process.env.HOST_NAME}/workspace/activity/dispute/track/${id}'>here</a>`
          },
        };
        await sendMail(message);
        break;
      case 'Disputant_Submitted_Offer':
        if (!workspace.isCounterpartyUnsubscribed) {
          message = {
            to: workspace.counterPartyEmail,
            from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
            templateId: TEMPLATE_ID.Submitted_Offer,
            dynamic_template_data: {
              action: 'created',
              subject: `Your dispute with ${workspace.createdBy.name} – submit your best offer`,
              partyName: workspace.createdBy.name,
              description: workspace.introduction,
              Link: `<a href='${process.env.HOST_NAME}/${link}'>here</a>`
            },
          };
          await sendMail(message);
        }
        break;
      case 'Disputant_Settlement_Figure':
        if (!workspace.isCounterpartyUnsubscribed) {
          message = {
            to: workspace.counterPartyEmail,
            from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
            templateId: TEMPLATE_ID.Settlement_Figure,
            dynamic_template_data: {
              subject: 'Congratulations!  You have a settlement waiting for you.',
              partyName: workspace.createdBy.name,
              Link: `<a href='${process.env.HOST_NAME}/workspace/activity/counterparty/track/${id}'>here</a>`
            },
          };
          await sendMail(message);
        }
        break;
      case 'Counterparty_Settlement_Figure':
        message = {
          to: workspace.createdBy.email,
          from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
          templateId: TEMPLATE_ID.Settlement_Figure,
          dynamic_template_data: {
            subject: 'Congratulations!  You have a settlement waiting for you.',
            partyName: workspace.counterPartyName,
            Link: `<a href='${process.env.HOST_NAME}/workspace/activity/dispute/track/${id}'>here</a>`
          },
        };
        await sendMail(message);
        break;
      case 'Counterparty_Offer_Comparison':
        // 8
        message = {
          to: workspace.createdBy.email,
          from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
          templateId: TEMPLATE_ID.Offer_Comparison,
          dynamic_template_data: {
            partyName: workspace.counterPartyName,
            subject: `Resolva has compared ${workspace.counterPartyName}'s best offer and your own.`,
            Link: `<a href='${process.env.HOST_NAME}/workspace/activity/dispute/track/${id}'>here</a>`
          },
        };
        await sendMail(message);
        break;
      case 'Disputant_Offer_Comparison':
        // 9
        if (!workspace.isCounterpartyUnsubscribed) {
          message = {
            to: workspace.counterPartyEmail,
            from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
            templateId: TEMPLATE_ID.Offer_Comparison,
            dynamic_template_data: {
              subject: `Resolva has compared ${workspace.createdBy.name}'s best offer and your own.`,
              partyName: workspace.createdBy.name,
              Link: `<a href='${process.env.HOST_NAME}/workspace/activity/counterparty/track/${id}'>here</a>`
            },
          };
          await sendMail(message);
        }
        break;
      case 'Counterparty_Sign_Agreement':
        // 10
        message = {
          to: workspace.createdBy.email,
          from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
          templateId: TEMPLATE_ID.Sign_Agreement,
          dynamic_template_data: {
            subject: 'You’ve got your settlement figure – now make it binding.',
            partyName: workspace.counterPartyName,
            Link: `<a href='${process.env.HOST_NAME}/workspace/activity/dispute/track/${id}'>here</a>`
          },
        };
        await sendMail(message);
        break;
      case 'Disputant_Sign_Agreement':
        // 11
        if (!workspace.isCounterpartyUnsubscribed) {
          message = {
            to: workspace.counterPartyEmail,
            from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
            templateId: TEMPLATE_ID.Sign_Agreement,
            dynamic_template_data: {
              subject: 'You’ve got your settlement figure – now make it binding.',
              partyName: workspace.createdBy.name,
              Link: `<a href='${process.env.HOST_NAME}/workspace/activity/counterparty/track/${id}'>here</a>`
            },
          };
          await sendMail(message);
        }
        break;
      case 'Disputant_Resolved':
        // 12
        message = {
          to: workspace.counterPartyEmail,
          from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
          templateId: TEMPLATE_ID.Resolved,
          dynamic_template_data: {
            subject: 'Congratulations on resolving your dispute!',
            partyName: workspace.createdBy.name,
            disputantSettlementUrl: `<a href='${workspace.disputantSettlementUrl}'>Disputant Settlement Agreement.pdf</a>`,
            counterPartySettlementUrl: `<a href='${workspace.counterPartySettlementUrl}'>Counterparty Settlement Agreement.pdf</a>`,
          },
        };
        await sendMail(message);
        break;
      case 'Counterparty_Resolved':
        // 13
        message = {
          to: workspace.createdBy.email,
          from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
          templateId: TEMPLATE_ID.Resolved,
          dynamic_template_data: {
            subject: 'Congratulations on resolving your dispute!',
            partyName: workspace.counterPartyName,
            disputantSettlementUrl: `<a href='${workspace.disputantSettlementUrl}'>Disputant Settlement Agreement.pdf</a>`,
            counterPartySettlementUrl: `<a href='${workspace.counterPartySettlementUrl}'>Counterparty Settlement Agreement.pdf</a>`,
          },
        };
        await sendMail(message);
        break;
      case 'created_workspace_no_offer':
        // 13
        message = {
          to: workspace.createdBy.email,
          from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
          templateId: TEMPLATE_ID.No_offer,
          dynamic_template_data: {
            subject: `Your dispute with ${workspace.counterPartyName} – submit your best offer`,
            partyName: workspace.counterPartyName,
            description: workspace.introduction,
            action: 'created',
            Link: `<a href='${process.env.HOST_NAME}/workspace/activity/dispute/track/${id}'>here</a>`
          },
        };
        await sendMail(message);
        break;
      case 'counterparty_joinded_no_offer':
        // 13
        if (!workspace.isCounterpartyUnsubscribed) {
          message = {
            to: workspace.counterPartyEmail,
            from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
            templateId: TEMPLATE_ID.No_offer,
            dynamic_template_data: {
              subject: `Your dispute with ${workspace.createdBy.name} – submit your best offer`,
              partyName: workspace.createdBy.name,
              description: workspace.introduction,
              action: 'joined',
              Link: `<a href='${process.env.HOST_NAME}/workspace/activity/counterparty/track/${id}'>here</a>`
            },
          };
          await sendMail(message);
        }
        break;
      case 'no_settlement':
        message = {
          to: 'admin@resolva.com.au',
          from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
          subject: 'no settlemnt Demo template',
          description: `the claiment Name and email is: ${workspace.createdBy.name}, ${workspace.createdBy.email} and the respondant Name and enmil is: ${workspace.createdBy.counterPartyName} ${workspace.counterPartyEmail} `
        };
        await sendMail(message);
        break;
      case 'resolve_settlement':
        message = {
          to: 'admin@resolva.com.au',
          from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
          subject: 'resolved settlemnt between two parties Demo template',
          description: `the claiment Name and email is: ${workspace.createdBy.name}, ${workspace.createdBy.email} and the respondant Name and enmil is: ${workspace.createdBy.counterPartyName} ${workspace.counterPartyEmail} `
        };
        await sendMail(message);
        break;
      default:
        break;
    }
  } catch (err) {
    logger.error(`Error while creating user ${err}`);
    throw err;
  }
};


// case 'no_settlement':
//         message = {
//           to: 'subham.deb@datacolada.com',
//           from: {email: TEMPLATE_ID.Sender_Mail, name: TEMPLATE_ID.Send_Name},
//           templateId: TEMPLATE_ID.No_offer,
//           dynamic_template_data: {
//             subject: 'no settlemnt Demo template',
//             description: `the claiment is: ${workspace.createdBy.email} and the respondant is: ${workspace.counterPartyEmail} `
//           },
//         };
//         await sendMail(message);
//         break;
