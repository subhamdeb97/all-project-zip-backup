import { Container } from 'typedi';
import { DEPENDENCY_CONTAINERS } from '../config/constants';

/**
 * Functionality used to remove fields from a object
 * @param {*} fields Array of fields to remove
 * @param {*} obj The object from which fields are to be removed
 * @returns {Object} object with fields removed.
 */
export const removefields = async(fields, obj) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    for (let i = 0; i < fields.length; i++) {
      if (obj[fields[i]]) {
        delete obj[fields[i]];
      }
    }
    return obj;
  } catch (err) {
    logger.error(`Error while removing fields from object ${err}`);
    throw err;
  }
};
/**
 * Functionality used to remove null from a object
 * @param {*} object The object from which fields are to be removed
 * @returns {Object} object with fields removed.
 */
export const removeEmptyNull = async(object) => {
  const logger = Container.get(DEPENDENCY_CONTAINERS.LOGGER);
  try {
    Object.entries(object).forEach( objects => (objects[1] === null ? delete object[objects[0]] : 0));
    return object;
  } catch (err) {
    logger.error(`Error while removing null from object ${err}`);
    throw err;
  }
};

module.exports = {
  removefields,
  removeEmptyNull
};
